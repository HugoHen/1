package com.speleologist.item;

import com.speleologist.SpeleologistMod;
import com.speleologist.block.ModBlocks;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import software.bernie.geckolib.animatable.GeoItem;

public class ModItems {
	public static final Item SPELEOLOGIST_EYE = new SpeleologistEyeItem(
			new Item.Properties().stacksTo(1).rarity(Rarity.RARE), false
	);
	public static final CyberScannerItem CYBER_SCANNER = new CyberScannerItem();
	public static final AUltimaItem A_ULTIMA = new AUltimaItem();
	public static final RedstoneFlowItem REDSTONE_FLOW = new RedstoneFlowItem();
	public static final IronFlowItem IRON_FLOW = new IronFlowItem();
	public static final Item FIRST_FLOW = new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());

	public static final Item PHOTON_FRAGMENT = new PhotonFragmentItem();
	public static final Item PHOTON_SEMI = new Item(new Item.Properties().rarity(Rarity.RARE));
	public static final Item PHOTON_COMPLETE = new Item(new Item.Properties().rarity(Rarity.EPIC));
	public static final Item BLACK_VORTEX = new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	public static final Item VORTEX_FOUNDRY = new Item(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));

	public static final CyberArmorItem CYBER_HELMET = new CyberArmorItem(net.minecraft.world.item.ArmorItem.Type.HELMET);
	public static final CyberArmorItem CYBER_CHESTPLATE = new CyberArmorItem(net.minecraft.world.item.ArmorItem.Type.CHESTPLATE);
	public static final CyberArmorItem CYBER_LEGGINGS = new CyberArmorItem(net.minecraft.world.item.ArmorItem.Type.LEGGINGS);
	public static final CyberArmorItem CYBER_BOOTS = new CyberArmorItem(net.minecraft.world.item.ArmorItem.Type.BOOTS);

	// Block items filled in registerBlockItems
	public static Item COMPACTED_REDSTONE, REDSTONE_2X, REDSTONE_3X, REDSTONE_COMPLETE;
	public static Item COMPACTED_IRON, IRON_2X, IRON_3X, IRON_COMPLETE;
	public static Item PHOTON_ORE, ADVANCED_CRAFTING_TABLE;

	public static void register() {
		reg("speleologist_eye", SPELEOLOGIST_EYE);
		reg("cyber_scanner", CYBER_SCANNER);
		reg("a_ultima", A_ULTIMA);
		reg("redstone_flow", REDSTONE_FLOW);
		reg("iron_flow", IRON_FLOW);
		reg("first_flow", FIRST_FLOW);
		reg("photon_fragment", PHOTON_FRAGMENT);
		reg("photon_semi", PHOTON_SEMI);
		reg("photon_complete", PHOTON_COMPLETE);
		reg("black_vortex", BLACK_VORTEX);
		reg("vortex_foundry", VORTEX_FOUNDRY);
		reg("cyber_helmet", CYBER_HELMET);
		reg("cyber_chestplate", CYBER_CHESTPLATE);
		reg("cyber_leggings", CYBER_LEGGINGS);
		reg("cyber_boots", CYBER_BOOTS);

		GeoItem.registerSyncedAnimatable(CYBER_HELMET);
		GeoItem.registerSyncedAnimatable(CYBER_CHESTPLATE);
		GeoItem.registerSyncedAnimatable(CYBER_LEGGINGS);
		GeoItem.registerSyncedAnimatable(CYBER_BOOTS);

		GeoItem.registerSyncedAnimatable(CYBER_SCANNER);
		GeoItem.registerSyncedAnimatable(A_ULTIMA);
	}

	private static void reg(String id, Item item) {
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id(id), item);
	}

	public static void registerBlockItems() {
		COMPACTED_REDSTONE = block("compacted_redstone", ModBlocks.COMPACTED_REDSTONE, Rarity.UNCOMMON);
		REDSTONE_2X = block("redstone_2x", ModBlocks.REDSTONE_2X, Rarity.RARE);
		REDSTONE_3X = block("redstone_3x", ModBlocks.REDSTONE_3X, Rarity.RARE);
		REDSTONE_COMPLETE = block("redstone_complete", ModBlocks.REDSTONE_COMPLETE, Rarity.EPIC);
		COMPACTED_IRON = block("compacted_iron", ModBlocks.COMPACTED_IRON, Rarity.UNCOMMON);
		IRON_2X = block("iron_2x", ModBlocks.IRON_2X, Rarity.RARE);
		IRON_3X = block("iron_3x", ModBlocks.IRON_3X, Rarity.RARE);
		IRON_COMPLETE = block("iron_complete", ModBlocks.IRON_COMPLETE, Rarity.EPIC);
		PHOTON_ORE = block("photon_ore", ModBlocks.PHOTON_ORE, Rarity.RARE);
		ADVANCED_CRAFTING_TABLE = new AdvancedCraftingTableItem(ModBlocks.ADVANCED_CRAFTING_TABLE, new Item.Properties());
		reg("advanced_crafting_table", ADVANCED_CRAFTING_TABLE);
		GeoItem.registerSyncedAnimatable((GeoItem) ADVANCED_CRAFTING_TABLE);
	}

	private static Item block(String id, net.minecraft.world.level.block.Block b, Rarity rarity) {
		Item item = new BlockItem(b, new Item.Properties().rarity(rarity));
		reg(id, item);
		return item;
	}
}
