package com.speleologist;

import com.speleologist.block.ModBlocks;
import com.speleologist.item.ModItems;
import com.speleologist.loot.ModLoot;
import com.speleologist.screen.ModMenuTypes;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpeleologistMod implements ModInitializer {
	public static final String MOD_ID = "olho_do_espeleologo";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static final CreativeModeTab SPELEOLOGIST_TAB = FabricItemGroup.builder()
			.icon(() -> new ItemStack(ModItems.SPELEOLOGIST_EYE))
			.title(Component.translatable("itemGroup.olho_do_espeleologo.main"))
			.displayItems((params, output) -> {
				output.accept(ModItems.SPELEOLOGIST_EYE);
				output.accept(ModItems.CYBER_SCANNER);
				output.accept(ModItems.A_ULTIMA);
				output.accept(ModItems.COMPACTED_REDSTONE);
				output.accept(ModItems.REDSTONE_2X);
				output.accept(ModItems.REDSTONE_3X);
				output.accept(ModItems.REDSTONE_COMPLETE);
				output.accept(ModItems.REDSTONE_FLOW);
				output.accept(ModItems.COMPACTED_IRON);
				output.accept(ModItems.IRON_2X);
				output.accept(ModItems.IRON_3X);
				output.accept(ModItems.IRON_COMPLETE);
				output.accept(ModItems.IRON_FLOW);
				output.accept(ModItems.FIRST_FLOW);
				output.accept(ModItems.PHOTON_FRAGMENT);
				output.accept(ModItems.PHOTON_SEMI);
				output.accept(ModItems.PHOTON_COMPLETE);
				output.accept(ModItems.BLACK_VORTEX);
				output.accept(ModItems.VORTEX_FOUNDRY);
				output.accept(ModItems.PHOTON_ORE);
				output.accept(ModItems.ADVANCED_CRAFTING_TABLE);
				output.accept(ModItems.CYBER_HELMET);
				output.accept(ModItems.CYBER_CHESTPLATE);
				output.accept(ModItems.CYBER_LEGGINGS);
				output.accept(ModItems.CYBER_BOOTS);
			})
			.build();

	@Override
	public void onInitialize() {
		ModBlocks.register();
		com.speleologist.block.ModBlockEntities.register();
		com.speleologist.item.CyberArmorMaterial.CYBER; // force register armor material
		ModItems.register();
		ModItems.registerBlockItems();
		ModMenuTypes.register();
		ModLoot.register();
		WorldGen.register();
		AUltimaHandler.register();
		CyberArmorHandler.register();

		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB,
				ResourceLocation.fromNamespaceAndPath(MOD_ID, "main"), SPELEOLOGIST_TAB);

		LOGGER.info("Speleologist's Eye loaded by krynox!");
	}

	public static ResourceLocation id(String path) {
		return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
	}
}
