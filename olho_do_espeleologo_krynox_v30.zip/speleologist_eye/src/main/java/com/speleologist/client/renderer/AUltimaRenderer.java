package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.speleologist.item.AUltimaItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/**
 * Geo: shaft along +Y, grip between gold rings at y≈11.
 * Target: Blockbench video — held forward from hands, head away from body.
 */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	private static final float GRIP = 11.0f / 16.0f;

	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}

	@Override
	public void renderByItem(net.minecraft.world.item.ItemStack stack, ItemDisplayContext ctx,
			PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
		pose.pushPose();

		switch (ctx) {
			case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
				// Lay Y-up shaft along the arm (forward), not vertical on the back
				float s = 0.42f;
				pose.scale(s, s, s);
				pose.translate(0, -GRIP * 16 * s * 0.15f, 0);
				// +Y was up → rotate so +Y points forward-up like a held pickaxe
				pose.mulPose(Axis.XP.rotationDegrees(90));
				pose.mulPose(Axis.ZP.rotationDegrees(ctx == ItemDisplayContext.THIRD_PERSON_LEFT_HAND ? 20 : -20));
				pose.translate(0, 0.2f, 0.35f);
			}
			case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> {
				// Latest FP shot was close — keep full head+handle in FOV
				float s = 0.45f;
				pose.scale(s, s, s);
				pose.translate(0, -GRIP * 8f, 0);
				pose.mulPose(Axis.XP.rotationDegrees(90));
				pose.mulPose(Axis.YP.rotationDegrees(ctx == ItemDisplayContext.FIRST_PERSON_LEFT_HAND ? 10 : -10));
				pose.translate(0.15f, 0.1f, 0.25f);
			}
			case GROUND -> {
				pose.scale(0.35f, 0.35f, 0.35f);
				pose.translate(0, 0.5f, 0);
				pose.mulPose(Axis.XP.rotationDegrees(90));
			}
			case FIXED -> {
				pose.scale(0.35f, 0.35f, 0.35f);
				pose.mulPose(Axis.ZP.rotationDegrees(-45));
				pose.translate(0, -0.5f, 0);
			}
			case GUI -> {
				pose.scale(0.28f, 0.28f, 0.28f);
				pose.mulPose(Axis.XP.rotationDegrees(30));
				pose.mulPose(Axis.YP.rotationDegrees(140));
				pose.translate(0, -0.3f, 0);
			}
			default -> {
				pose.scale(0.4f, 0.4f, 0.4f);
				pose.translate(0, -GRIP, 0);
			}
		}

		super.renderByItem(stack, ctx, pose, buffers, light, overlay);
		pose.popPose();
	}
}
