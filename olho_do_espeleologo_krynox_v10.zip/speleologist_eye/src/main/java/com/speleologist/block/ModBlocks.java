package com.speleologist.block;

import com.speleologist.SpeleologistMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.util.valueproviders.UniformInt;

public class ModBlocks {
	// Harder than diamond ore (3.0), softer than ancient debris / netherite (30.0)
	public static final Block PHOTON_ORE = new DropExperienceBlock(
			UniformInt.of(2, 5),
			BlockBehaviour.Properties.ofFullCopy(Blocks.DIAMOND_ORE)
					.mapColor(MapColor.COLOR_PURPLE)
					.instrument(NoteBlockInstrument.BASEDRUM)
					.requiresCorrectToolForDrops()
					.strength(8.0f, 8.0f)
	);

	public static final Block ADVANCED_CRAFTING_TABLE = new AdvancedCraftingTableBlock();

	public static void register() {
		Registry.register(BuiltInRegistries.BLOCK, SpeleologistMod.id("photon_ore"), PHOTON_ORE);
		Registry.register(BuiltInRegistries.BLOCK, SpeleologistMod.id("advanced_crafting_table"), ADVANCED_CRAFTING_TABLE);
	}
}
