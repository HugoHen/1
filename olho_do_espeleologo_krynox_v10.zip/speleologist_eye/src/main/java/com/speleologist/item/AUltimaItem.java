package com.speleologist.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.List;

public class AUltimaItem extends Item {
	public static final String DAMAGE_TAG = "UltimaDamage";
	public static final float BASE_DAMAGE = 50f;
	public static final float MAX_DAMAGE = 1_000_000f;

	public AUltimaItem() {
		super(new Item.Properties()
				.stacksTo(1)
				.rarity(Rarity.EPIC)
				.fireResistant()
				.attributes(createAttributes(BASE_DAMAGE))
				.component(DataComponents.UNBREAKABLE, new Unbreakable(true))
		);
	}

	public static ItemAttributeModifiers createAttributes(float attackDamage) {
		return ItemAttributeModifiers.builder()
				.add(Attributes.ATTACK_DAMAGE,
						new AttributeModifier(BASE_ATTACK_DAMAGE_ID, attackDamage, AttributeModifier.Operation.ADD_VALUE),
						EquipmentSlotGroup.MAINHAND)
				.add(Attributes.ATTACK_SPEED,
						new AttributeModifier(BASE_ATTACK_SPEED_ID, -2.4, AttributeModifier.Operation.ADD_VALUE),
						EquipmentSlotGroup.MAINHAND)
				.build();
	}

	public static float getDamageLevel(ItemStack stack) {
		try {
			var custom = stack.get(DataComponents.CUSTOM_DATA);
			if (custom != null) {
				var tag = custom.copyTag();
				if (tag.contains(DAMAGE_TAG)) {
					return Math.min(MAX_DAMAGE, Math.max(BASE_DAMAGE, tag.getFloat(DAMAGE_TAG)));
				}
			}
		} catch (Exception ignored) {}
		return BASE_DAMAGE;
	}

	public static void setDamageLevel(ItemStack stack, float damage) {
		damage = Math.min(MAX_DAMAGE, Math.max(BASE_DAMAGE, damage));
		try {
			var custom = stack.getOrDefault(DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.EMPTY);
			var tag = custom.copyTag();
			tag.putFloat(DAMAGE_TAG, damage);
			stack.set(DataComponents.CUSTOM_DATA, net.minecraft.world.item.component.CustomData.of(tag));
			stack.set(DataComponents.ATTRIBUTE_MODIFIERS, createAttributes(damage));
		} catch (Exception ignored) {}
	}

	@Override
	public float getDestroySpeed(ItemStack stack, BlockState state) {
		return 45f;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack stack, BlockState state) {
		return true;
	}

	@Override
	public boolean mineBlock(ItemStack stack, Level level, BlockState state, BlockPos pos, LivingEntity entity) {
		return true;
	}

	@Override
	public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		return true;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		float dmg = getDamageLevel(stack);
		tooltip.add(Component.literal("§5§o\"there is nothing I cannot break...\""));
		tooltip.add(Component.literal("§7Pickaxe + Axe"));
		tooltip.add(Component.literal("§7Efficiency 10 | Fortune 10 | Sharpness 10"));
		tooltip.add(Component.literal("§bUnbreakable"));
		tooltip.add(Component.literal("§7Breaks Bedrock"));
		tooltip.add(Component.literal(String.format("§cDamage: §f%.0f §8/ 1000000", dmg)));
		super.appendHoverText(stack, context, tooltip, flag);
	}
}
