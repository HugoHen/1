package com.speleologist.item;

import com.speleologist.SpeleologistMod;
import com.speleologist.block.ModBlocks;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public class ModItems {
	public static final Item SPELEOLOGIST_EYE = new SpeleologistEyeItem(
			new Item.Properties().stacksTo(1).rarity(Rarity.RARE), false
	);
	public static final Item CYBER_SCANNER = new CyberScannerItem(
			new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()
	);
	public static final Item A_ULTIMA = new AUltimaItem();

	public static final Item PHOTON_FRAGMENT = new Item(new Item.Properties().rarity(Rarity.UNCOMMON));
	public static final Item PHOTON_SEMI = new Item(new Item.Properties().rarity(Rarity.RARE));
	public static final Item PHOTON_COMPLETE = new Item(new Item.Properties().rarity(Rarity.EPIC));
	public static final Item COMPACTED_REDSTONE = new Item(new Item.Properties().rarity(Rarity.RARE));
	public static final Item COMPACTED_IRON = new Item(new Item.Properties().rarity(Rarity.RARE));
	public static final Item BLACK_VORTEX = new Item(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

	public static Item PHOTON_ORE;
	public static Item ADVANCED_CRAFTING_TABLE;

	public static void register() {
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("speleologist_eye"), SPELEOLOGIST_EYE);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("cyber_scanner"), CYBER_SCANNER);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("a_ultima"), A_ULTIMA);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("photon_fragment"), PHOTON_FRAGMENT);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("photon_semi"), PHOTON_SEMI);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("photon_complete"), PHOTON_COMPLETE);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("compacted_redstone"), COMPACTED_REDSTONE);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("compacted_iron"), COMPACTED_IRON);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("black_vortex"), BLACK_VORTEX);
	}

	public static void registerBlockItems() {
		PHOTON_ORE = new BlockItem(ModBlocks.PHOTON_ORE, new Item.Properties().rarity(Rarity.RARE));
		ADVANCED_CRAFTING_TABLE = new BlockItem(ModBlocks.ADVANCED_CRAFTING_TABLE, new Item.Properties());
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("photon_ore"), PHOTON_ORE);
		Registry.register(BuiltInRegistries.ITEM, SpeleologistMod.id("advanced_crafting_table"), ADVANCED_CRAFTING_TABLE);
	}
}
