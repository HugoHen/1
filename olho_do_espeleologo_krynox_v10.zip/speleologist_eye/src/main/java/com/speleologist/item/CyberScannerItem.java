package com.speleologist.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class CyberScannerItem extends Item {
	public CyberScannerItem(Properties properties) {
		super(properties);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);

		if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
			boolean hasFuel = false;
			for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
				ItemStack invStack = player.getInventory().getItem(i);
				if (invStack.is(Items.REDSTONE) && invStack.getCount() > 0) {
					invStack.shrink(1);
					hasFuel = true;
					break;
				}
			}

			if (!hasFuel) {
				serverPlayer.sendSystemMessage(Component.literal("§cNo Redstone fuel! Need Redstone Dust."));
				return InteractionResultHolder.fail(stack);
			}

			serverPlayer.sendSystemMessage(Component.literal("§bCyber Scanner activated! (3 min)"));
		}

		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		tooltip.add(Component.literal("§6Cyber Scanner"));
		tooltip.add(Component.literal("§7Range: 81x81 | Duration: 3 minutes"));
		tooltip.add(Component.literal("§7Fuel: 1 Redstone Dust per use"));
		tooltip.add(Component.literal("§7Reveals all ores + chests"));
		super.appendHoverText(stack, context, tooltip, flag);
	}
}
