package com.speleologist.screen;

import com.speleologist.item.ModItems;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

import java.util.Optional;

public class AdvancedCraftingMenu extends AbstractContainerMenu {
	public static final int GRID = 5;
	public static final int GRID_SIZE = 25;

	private final CraftingContainer craftSlots;
	private final ResultContainer resultSlots = new ResultContainer();
	private final ContainerLevelAccess access;
	private final Player player;
	private final Level level;

	public AdvancedCraftingMenu(int syncId, Inventory playerInv) {
		this(syncId, playerInv, ContainerLevelAccess.NULL);
	}

	public AdvancedCraftingMenu(int syncId, Inventory playerInv, ContainerLevelAccess access) {
		super(ModMenuTypes.ADVANCED_CRAFTING, syncId);
		this.access = access;
		this.player = playerInv.player;
		this.level = playerInv.player.level();
		this.craftSlots = new CraftingContainer(this, GRID_SIZE);

		// 5x5 grid
		for (int row = 0; row < GRID; row++) {
			for (int col = 0; col < GRID; col++) {
				this.addSlot(new Slot(craftSlots, col + row * GRID, 12 + col * 18, 17 + row * 18));
			}
		}

		// Result slot - only take via onTake
		this.addSlot(new Slot(resultSlots, 0, 147, 53) {
			@Override
			public boolean mayPlace(ItemStack stack) {
				return false;
			}

			@Override
			public void onTake(Player player, ItemStack stack) {
				// Consume 1 from each non-empty craft slot
				for (int i = 0; i < GRID_SIZE; i++) {
					ItemStack s = craftSlots.getItem(i);
					if (!s.isEmpty()) {
						s.shrink(1);
						if (s.isEmpty()) craftSlots.setItemSilent(i, ItemStack.EMPTY);
						else craftSlots.setItemSilent(i, s);
					}
				}
				craftSlots.setChanged();
				super.onTake(player, stack);
			}

			@Override
			public boolean mayPickup(Player player) {
				return hasItem();
			}
		});

		// Player inventory
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 120 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInv, col, 8 + col * 18, 178));
		}
	}

	@Override
	public void slotsChanged(Container container) {
		if (level == null || level.isClientSide) {
			return;
		}
		updateResult();
	}

	private void updateResult() {
		ItemStack result = ItemStack.EMPTY;

		int photonFrags = 0, redstoneBlocks = 0, ironBlocks = 0;
		int filled = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (s.isEmpty()) continue;
			filled++;
			if (s.is(ModItems.PHOTON_FRAGMENT)) photonFrags++;
			else if (s.is(Items.REDSTONE_BLOCK)) redstoneBlocks++;
			else if (s.is(Items.IRON_BLOCK)) ironBlocks++;
		}

		// Custom 5x5 recipes (all 25 slots same item)
		if (photonFrags == 25 && filled == 25) {
			result = new ItemStack(ModItems.PHOTON_SEMI);
		} else if (redstoneBlocks == 25 && filled == 25) {
			result = new ItemStack(ModItems.COMPACTED_REDSTONE);
		} else if (ironBlocks == 25 && filled == 25) {
			result = new ItemStack(ModItems.COMPACTED_IRON);
		} else {
			// Try vanilla 3x3 using center (or top-left 3x3)
			result = tryVanillaRecipe();
		}

		resultSlots.setItem(0, result);
		broadcastChanges();
	}

	private ItemStack tryVanillaRecipe() {
		if (level == null || level.isClientSide) return ItemStack.EMPTY;
		try {
			// Build 3x3 input from top-left of 5x5 grid
			NonNullList<ItemStack> items = NonNullList.withSize(9, ItemStack.EMPTY);
			for (int row = 0; row < 3; row++) {
				for (int col = 0; col < 3; col++) {
					items.set(col + row * 3, craftSlots.getItem(col + row * GRID).copy());
				}
			}
			// Check rest of 5x5 is empty for vanilla match
			boolean only3x3 = true;
			for (int i = 0; i < GRID_SIZE; i++) {
				int r = i / GRID, c = i % GRID;
				if (r >= 3 || c >= 3) {
					if (!craftSlots.getItem(i).isEmpty()) {
						only3x3 = false;
						break;
					}
				}
			}
			if (!only3x3) return ItemStack.EMPTY;

			CraftingInput input = CraftingInput.of(3, 3, items);
			Optional<RecipeHolder<CraftingRecipe>> opt = level.getRecipeManager()
					.getRecipeFor(RecipeType.CRAFTING, input, level);
			if (opt.isPresent()) {
				return opt.get().value().assemble(input, level.registryAccess());
			}
		} catch (Exception ignored) {}
		return ItemStack.EMPTY;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		ItemStack newStack = ItemStack.EMPTY;
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;

		ItemStack original = slot.getItem();
		newStack = original.copy();

		if (index == GRID_SIZE) {
			// Result -> player inventory (onTake handles consume)
			if (!this.moveItemStackTo(original, GRID_SIZE + 1, this.slots.size(), true)) {
				return ItemStack.EMPTY;
			}
			slot.onQuickCraft(original, newStack);
			slot.onTake(player, original);
		} else if (index > GRID_SIZE) {
			// Player inv -> grid
			if (!this.moveItemStackTo(original, 0, GRID_SIZE, false)) {
				return ItemStack.EMPTY;
			}
		} else {
			// Grid -> player inv
			if (!this.moveItemStackTo(original, GRID_SIZE + 1, this.slots.size(), false)) {
				return ItemStack.EMPTY;
			}
		}

		if (original.isEmpty()) {
			slot.setByPlayer(ItemStack.EMPTY);
		} else {
			slot.setChanged();
		}

		if (index != GRID_SIZE) {
			slotsChanged(craftSlots);
		}
		return newStack;
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.access.execute((level, pos) -> this.clearContainer(player, craftSlots));
	}

	/** Container that notifies menu without recursive loops */
	static class CraftingContainer implements Container {
		private final NonNullList<ItemStack> items;
		private final AdvancedCraftingMenu menu;
		private boolean silent = false;

		CraftingContainer(AdvancedCraftingMenu menu, int size) {
			this.menu = menu;
			this.items = NonNullList.withSize(size, ItemStack.EMPTY);
		}

		void setItemSilent(int i, ItemStack stack) {
			silent = true;
			items.set(i, stack);
			silent = false;
		}

		@Override public int getContainerSize() { return items.size(); }
		@Override public boolean isEmpty() {
			for (ItemStack s : items) if (!s.isEmpty()) return false;
			return true;
		}
		@Override public ItemStack getItem(int i) { return items.get(i); }

		@Override
		public ItemStack removeItem(int i, int count) {
			ItemStack r = ContainerHelper.removeItem(items, i, count);
			if (!r.isEmpty() && !silent) menu.slotsChanged(this);
			return r;
		}

		@Override
		public ItemStack removeItemNoUpdate(int i) {
			return ContainerHelper.takeItem(items, i);
		}

		@Override
		public void setItem(int i, ItemStack stack) {
			items.set(i, stack);
			if (!silent) menu.slotsChanged(this);
		}

		@Override
		public void setChanged() {
			if (!silent) menu.slotsChanged(this);
		}

		@Override public boolean stillValid(Player player) { return true; }
		@Override public void clearContent() { items.clear(); }
	}
}
