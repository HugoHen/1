package com.speleologist;

import com.speleologist.item.AUltimaItem;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class AUltimaHandler {
	public static void register() {
		// Bedrock cannot be mined normally (hardness -1). Intercept left-click.
		AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
			if (world.isClientSide) return InteractionResult.PASS;
			ItemStack tool = player.getMainHandItem();
			if (!(tool.getItem() instanceof AUltimaItem)) return InteractionResult.PASS;

			BlockState state = world.getBlockState(pos);
			if (state.is(Blocks.BEDROCK) || state.is(Blocks.BARRIER)
					|| state.is(Blocks.END_PORTAL_FRAME) || state.is(Blocks.END_PORTAL)
					|| state.getDestroySpeed(world, pos) < 0) {
				world.levelEvent(2001, pos, Block.getId(state));
				world.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
				return InteractionResult.SUCCESS;
			}
			return InteractionResult.PASS;
		});

		// Fortune-like extra drops for ores
		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (world.isClientSide || !(world instanceof ServerLevel serverLevel)) return;
			ItemStack tool = player.getMainHandItem();
			if (!(tool.getItem() instanceof AUltimaItem)) return;

			String name = state.getBlock().getDescriptionId().toLowerCase();
			if (!(name.contains("ore") || name.contains("debris") || name.contains("photon"))) return;

			try {
				LootParams.Builder builder = new LootParams.Builder(serverLevel)
						.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
						.withParameter(LootContextParams.TOOL, tool)
						.withOptionalParameter(LootContextParams.THIS_ENTITY, player);
				List<ItemStack> drops = state.getDrops(builder);
				for (ItemStack drop : drops) {
					if (!drop.isEmpty()) {
						ItemStack extra = drop.copy();
						extra.setCount(Math.min(64, Math.max(1, drop.getCount() * 5)));
						Block.popResource(world, pos, extra);
					}
				}
			} catch (Exception ignored) {}
		});
	}
}
