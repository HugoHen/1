package com.speleologist.client.screen;

import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class AdvancedCraftingScreen extends AbstractContainerScreen<AdvancedCraftingMenu> {

	public AdvancedCraftingScreen(AdvancedCraftingMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		this.imageWidth = 176;
		this.imageHeight = 202;
		this.inventoryLabelY = 108;
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float delta, int mouseX, int mouseY) {
		int x = (width - imageWidth) / 2;
		int y = (height - imageHeight) / 2;

		// Outer frame
		graphics.fill(x, y, x + imageWidth, y + imageHeight, 0xFF2B2B2B);
		graphics.fill(x + 1, y + 1, x + imageWidth - 1, y + imageHeight - 1, 0xFFC6C6C6);
		graphics.fill(x + 3, y + 3, x + imageWidth - 3, y + imageHeight - 3, 0xFF8B8B8B);

		// Title bar
		graphics.fill(x + 3, y + 3, x + imageWidth - 3, y + 16, 0xFFA0A0A0);

		// 5x5 slots
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				int sx = x + 11 + col * 18;
				int sy = y + 16 + row * 18;
				graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF373737);
				graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
			}
		}

		// Arrow area / result
		graphics.fill(x + 110, y + 52, x + 140, y + 70, 0xFF8B8B8B);
		graphics.fill(x + 146, y + 52, x + 164, y + 70, 0xFF373737);
		graphics.fill(x + 147, y + 53, x + 163, y + 69, 0xFF8B8B8B);

		// Player inventory background
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				int sx = x + 7 + col * 18;
				int sy = y + 119 + row * 18;
				graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF373737);
				graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
			}
		}
		for (int col = 0; col < 9; col++) {
			int sx = x + 7 + col * 18;
			int sy = y + 177;
			graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF373737);
			graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF8B8B8B);
		}
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		renderBackground(graphics, mouseX, mouseY, delta);
		super.render(graphics, mouseX, mouseY, delta);
		renderTooltip(graphics, mouseX, mouseY);
	}
}
