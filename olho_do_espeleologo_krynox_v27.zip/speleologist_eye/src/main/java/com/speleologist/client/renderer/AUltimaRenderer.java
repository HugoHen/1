package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.speleologist.item.AUltimaItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/**
 * Shaft is along +Y in the geo. Gold rings sit near y≈8 and y≈14 on the brown handle.
 * Grip point (between rings) ≈ y 11. Shift so that point is at the hand.
 */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	private static final float GRIP_Y = 11.0f;
	private static final float U = 1.0f / 16.0f;

	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}

	@Override
	public void renderByItem(net.minecraft.world.item.ItemStack stack, ItemDisplayContext ctx,
			PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
		pose.pushPose();
		// Move model so grip lands at local origin (hand)
		float dy = -GRIP_Y * U;

		switch (ctx) {
			case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND ->
				pose.translate(0, dy + 0.05f, 0);
			case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND ->
				pose.translate(0, dy + 0.1f, 0);
			case GROUND -> {
				pose.translate(0, 0.2f, 0);
				pose.scale(1.2f, 1.2f, 1.2f);
			}
			case FIXED -> // item frame — lay like a hung tool
				pose.translate(0, dy * 0.4f, 0);
			case GUI ->
				pose.translate(0, dy * 0.5f, 0);
			default -> {
			}
		}

		super.renderByItem(stack, ctx, pose, buffers, light, overlay);
		pose.popPose();
	}
}
