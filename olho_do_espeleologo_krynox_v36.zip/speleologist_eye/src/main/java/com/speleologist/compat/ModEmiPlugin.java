package com.speleologist.compat;

import com.speleologist.SpeleologistMod;
import com.speleologist.item.ModItems;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class ModEmiPlugin implements EmiPlugin {
	public static final ResourceLocation ID = SpeleologistMod.id("advanced_5x5");
	public static final EmiStack WORKSTATION = EmiStack.of(ModItems.ADVANCED_CRAFTING_TABLE);
	public static final EmiRecipeCategory CATEGORY = new EmiRecipeCategory(ID, WORKSTATION);
	private static final Set<Integer> DIAMOND = Set.of(2, 6, 8, 10, 14, 16, 18, 22);

	@Override
	public void register(EmiRegistry registry) {
		registry.addCategory(CATEGORY);
		registry.addWorkstation(CATEGORY, WORKSTATION);

		fill(registry, "compacted_redstone", EmiStack.of(Items.REDSTONE_BLOCK), EmiStack.of(ModItems.COMPACTED_REDSTONE));
		fill(registry, "redstone_2x", EmiStack.of(ModItems.COMPACTED_REDSTONE), EmiStack.of(ModItems.REDSTONE_2X));
		fill(registry, "redstone_3x", EmiStack.of(ModItems.REDSTONE_2X), EmiStack.of(ModItems.REDSTONE_3X));
		fill(registry, "redstone_complete", EmiStack.of(ModItems.REDSTONE_3X), EmiStack.of(ModItems.REDSTONE_COMPLETE));
		fill(registry, "compacted_iron", EmiStack.of(Items.IRON_BLOCK), EmiStack.of(ModItems.COMPACTED_IRON));
		fill(registry, "iron_2x", EmiStack.of(ModItems.COMPACTED_IRON), EmiStack.of(ModItems.IRON_2X));
		fill(registry, "iron_3x", EmiStack.of(ModItems.IRON_2X), EmiStack.of(ModItems.IRON_3X));
		fill(registry, "iron_complete", EmiStack.of(ModItems.IRON_3X), EmiStack.of(ModItems.IRON_COMPLETE));
		fill(registry, "photon_semi", EmiStack.of(ModItems.PHOTON_FRAGMENT), EmiStack.of(ModItems.PHOTON_SEMI));

		List<EmiIngredient> a = new ArrayList<>(Collections.nCopies(25, EmiStack.of(ModItems.REDSTONE_COMPLETE)));
		a.set(12, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/redstone_flow"), a, EmiStack.of(ModItems.REDSTONE_FLOW, 2)));

		List<EmiIngredient> b = new ArrayList<>(Collections.nCopies(25, EmiStack.of(ModItems.IRON_COMPLETE)));
		b.set(12, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/iron_flow"), b, EmiStack.of(ModItems.IRON_FLOW, 2)));

		EmiStack D = EmiStack.of(Items.DIAMOND_BLOCK);
		EmiStack E = EmiStack.of(Items.ENDER_EYE);
		EmiStack RF = EmiStack.of(ModItems.REDSTONE_FLOW);
		EmiStack IF = EmiStack.of(ModItems.IRON_FLOW);
		List<EmiIngredient> first = new ArrayList<>();
		int rf = 8;
		for (int i = 0; i < 25; i++) {
			if (i == 12) first.add(E);
			else if (DIAMOND.contains(i)) first.add(D);
			else if (rf > 0) { first.add(RF); rf--; }
			else first.add(IF);
		}
		registry.addRecipe(new R(SpeleologistMod.id("emi/first_flow"), first, EmiStack.of(ModItems.FIRST_FLOW)));
	}

	private void fill(EmiRegistry reg, String id, EmiStack in, EmiStack out) {
		reg.addRecipe(new R(SpeleologistMod.id("emi/" + id), Collections.nCopies(25, in), out));
	}

	static class R implements EmiRecipe {
		final ResourceLocation id;
		final List<EmiIngredient> inputs;
		final EmiStack output;
		R(ResourceLocation id, List<EmiIngredient> inputs, EmiStack output) {
			this.id = id; this.inputs = inputs; this.output = output;
		}
		@Override public EmiRecipeCategory getCategory() { return CATEGORY; }
		@Override public ResourceLocation getId() { return id; }
		@Override public List<EmiIngredient> getInputs() { return inputs; }
		@Override public List<EmiStack> getOutputs() { return List.of(output); }
		@Override public int getDisplayWidth() { return 134; }
		@Override public int getDisplayHeight() { return 98; }
		@Override public void addWidgets(WidgetHolder w) {
			for (int i = 0; i < Math.min(25, inputs.size()); i++)
				w.addSlot(inputs.get(i), (i % 5) * 18, (i / 5) * 18);
			w.addSlot(output, 108, 36).recipeContext(this);
		}
	}
}
