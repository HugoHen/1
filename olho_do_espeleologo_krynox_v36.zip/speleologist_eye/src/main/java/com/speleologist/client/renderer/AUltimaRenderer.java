package com.speleologist.client.renderer;

import com.speleologist.item.AUltimaItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/** Pose comes from models/item/a_ultima.json (Blockbench Display export). */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}
}
