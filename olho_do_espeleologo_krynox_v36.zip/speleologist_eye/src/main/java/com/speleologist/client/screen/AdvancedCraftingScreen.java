package com.speleologist.client.screen;

import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class AdvancedCraftingScreen extends AbstractContainerScreen<AdvancedCraftingMenu> {

	// Use vanilla crafting table texture style colors (wood)
	private static final int BG = 0xFFC6C6C6;
	private static final int BG_DARK = 0xFF8B8B8B;
	private static final int SLOT = 0xFF8B8B8B;
	private static final int SLOT_INNER = 0xFF373737;
	private static final int HIGHLIGHT = 0xFFFFFFFF;
	private static final int SHADOW = 0xFF555555;

	public AdvancedCraftingScreen(AdvancedCraftingMenu menu, Inventory inv, Component title) {
		super(menu, inv, Component.literal("Crafting"));
		this.imageWidth = 176;
		this.imageHeight = 202;
		this.inventoryLabelY = 108;
		this.titleLabelY = 6;
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float delta, int mouseX, int mouseY) {
		int x = (width - imageWidth) / 2;
		int y = (height - imageHeight) / 2;

		// Outer panel like vanilla
		graphics.fill(x, y, x + imageWidth, y + imageHeight, BG);
		// border
		graphics.fill(x, y, x + imageWidth, y + 1, HIGHLIGHT);
		graphics.fill(x, y, x + 1, y + imageHeight, HIGHLIGHT);
		graphics.fill(x + imageWidth - 1, y, x + imageWidth, y + imageHeight, SHADOW);
		graphics.fill(x, y + imageHeight - 1, x + imageWidth, y + imageHeight, SHADOW);

		// 5x5 grid slots (vanilla slot look)
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				drawSlot(graphics, x + 11 + col * 18, y + 16 + row * 18);
			}
		}

		// Arrow
		graphics.fill(x + 118, y + 58, x + 136, y + 64, SLOT_INNER);

		// Result slot
		drawSlot(graphics, x + 146, y + 52);
		// result bigger frame
		graphics.fill(x + 142, y + 48, x + 168, y + 74, BG_DARK);
		drawSlot(graphics, x + 146, y + 52);

		// Player inventory
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				drawSlot(graphics, x + 7 + col * 18, y + 119 + row * 18);
			}
		}
		for (int col = 0; col < 9; col++) {
			drawSlot(graphics, x + 7 + col * 18, y + 177);
		}
	}

	private void drawSlot(GuiGraphics g, int sx, int sy) {
		g.fill(sx, sy, sx + 18, sy + 18, SLOT);
		g.fill(sx + 1, sy + 1, sx + 17, sy + 17, SLOT_INNER);
		g.fill(sx, sy, sx + 18, sy + 1, SHADOW);
		g.fill(sx, sy, sx + 1, sy + 18, SHADOW);
		g.fill(sx + 17, sy, sx + 18, sy + 18, HIGHLIGHT);
		g.fill(sx, sy + 17, sx + 18, sy + 18, HIGHLIGHT);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		renderBackground(graphics, mouseX, mouseY, delta);
		super.render(graphics, mouseX, mouseY, delta);
		renderTooltip(graphics, mouseX, mouseY);
	}

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
		graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 0x404040, false);
	}
}
