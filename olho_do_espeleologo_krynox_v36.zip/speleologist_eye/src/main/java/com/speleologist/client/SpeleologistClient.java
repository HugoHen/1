package com.speleologist.client;

import com.speleologist.client.screen.AdvancedCraftingScreen;
import com.speleologist.item.CyberScannerItem;
import com.speleologist.item.SpeleologistEyeItem;
import com.speleologist.screen.ModMenuTypes;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import com.speleologist.block.ModBlockEntities;
import com.speleologist.client.renderer.AdvancedCraftingTableRenderer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

public class SpeleologistClient implements ClientModInitializer {
	private static long activeUntil = 0;
	private static boolean scannerMode = false;
	private static boolean swingHandled = false; // only one activation per swing
	private static final Set<BlockPos> foundOres = new HashSet<>();
	private static final Set<BlockPos> foundChests = new HashSet<>();
	private static int scanCooldown = 0;
	private static int actionbarCooldown = 0;

	private static final float[] WHITE = {1f, 1f, 1f, 0.95f};
	private static final float[] DIAMOND = {0.3f, 0.9f, 1f, 0.95f};
	private static final float[] IRON = {0.85f, 0.85f, 0.9f, 0.9f};
	private static final float[] GOLD = {1f, 0.85f, 0.2f, 0.95f};
	private static final float[] REDSTONE = {1f, 0.2f, 0.2f, 0.95f};
	private static final float[] EMERALD = {0.2f, 1f, 0.4f, 0.95f};
	private static final float[] LAPIS = {0.3f, 0.4f, 1f, 0.95f};
	private static final float[] COAL = {0.3f, 0.3f, 0.3f, 0.9f};
	private static final float[] COPPER = {1f, 0.55f, 0.3f, 0.95f};
	private static final float[] ANCIENT = {0.6f, 0.3f, 0.2f, 0.95f};
	private static final float[] PHOTON = {0.3f, 1f, 1f, 1f};
	private static final float[] CHEST = {1f, 0.8f, 0.15f, 0.95f};

	@Override
	public void onInitializeClient() {
		BlockEntityRenderers.register(ModBlockEntities.ADVANCED_CRAFTING_TABLE, AdvancedCraftingTableRenderer::new);
		MenuScreens.register(ModMenuTypes.ADVANCED_CRAFTING, AdvancedCraftingScreen::new);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null || client.level == null) return;
			Player player = client.player;

			ItemStack main = player.getMainHandItem();
			ItemStack off = player.getOffhandItem();
			boolean holdingEye = main.getItem() instanceof SpeleologistEyeItem || off.getItem() instanceof SpeleologistEyeItem;
			boolean holdingScanner = main.getItem() instanceof CyberScannerItem || off.getItem() instanceof CyberScannerItem;

			// Activation ONLY on a new swing (actual click/use), never by just holding
			if (player.swinging) {
				if (!swingHandled) {
					swingHandled = true;

					if (holdingEye) {
						// Eye: only if NOT already on cooldown (server will set cooldown on real use)
						var eyeItem = main.getItem() instanceof SpeleologistEyeItem ? main.getItem() : off.getItem();
						if (!player.getCooldowns().isOnCooldown(eyeItem)) {
							// Will be on cooldown after server processes use - activate effect now
							scannerMode = false;
							activeUntil = client.level.getGameTime() + 10 * 20L;
							foundOres.clear();
							foundChests.clear();
							scanNearby(player);
						}
						// If already on cooldown, do NOTHING (don't re-activate)
					}

					if (holdingScanner) {
						// Scanner: only if player has Redstone fuel
						if (hasRedstone(player)) {
							scannerMode = true;
							activeUntil = client.level.getGameTime() + 3 * 60 * 20L;
							foundOres.clear();
							foundChests.clear();
							scanNearby(player);
						}
					}
				}
			} else {
				swingHandled = false;
			}

			// Effect only runs while timer is active — holding item does nothing by itself
			if (client.level.getGameTime() < activeUntil) {
				actionbarCooldown--;
				if (actionbarCooldown <= 0) {
					long ticksLeft = activeUntil - client.level.getGameTime();
					int sec = (int) (ticksLeft / 20);
					String mode = scannerMode ? "§bScanner" : "§aEye";
					player.displayClientMessage(Component.literal(String.format("%s §f%02d:%02d", mode, sec / 60, sec % 60)), true);
					actionbarCooldown = 20;
				}

				scanCooldown--;
				if (scanCooldown <= 0) {
					updateScan(player);
					scanCooldown = 20;
				}
			} else {
				foundOres.clear();
				foundChests.clear();
			}
		});

		WorldRenderEvents.AFTER_TRANSLUCENT.register(SpeleologistClient::renderOutlines);
	}

	private static boolean hasRedstone(Player player) {
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack s = player.getInventory().getItem(i);
			if (s.is(Items.REDSTONE) && s.getCount() > 0) return true;
		}
		return false;
	}

	private static void scanNearby(Player player) {
		int range = scannerMode ? 40 : 8;
		int rangeY = scannerMode ? 40 : 8;
		BlockPos origin = player.blockPosition();
		for (int x = -range; x <= range; x++) {
			for (int y = -rangeY; y <= rangeY; y++) {
				for (int z = -range; z <= range; z++) {
					if (x * x + z * z > range * range) continue;
					BlockPos pos = origin.offset(x, y, z);
					BlockState state = player.level().getBlockState(pos);
					if (isOre(state)) foundOres.add(pos.immutable());
					if (scannerMode && isChest(state)) foundChests.add(pos.immutable());
				}
			}
		}
	}

	private static void updateScan(Player player) {
		int range = scannerMode ? 40 : 8;
		int rangeY = scannerMode ? 40 : 8;
		BlockPos origin = player.blockPosition();

		foundOres.removeIf(pos -> {
			if (!isOre(player.level().getBlockState(pos))) return true;
			int dx = pos.getX() - origin.getX();
			int dy = pos.getY() - origin.getY();
			int dz = pos.getZ() - origin.getZ();
			return dx * dx + dz * dz > range * range || Math.abs(dy) > rangeY;
		});
		if (scannerMode) {
			foundChests.removeIf(pos -> {
				if (!isChest(player.level().getBlockState(pos))) return true;
				int dx = pos.getX() - origin.getX();
				int dy = pos.getY() - origin.getY();
				int dz = pos.getZ() - origin.getZ();
				return dx * dx + dz * dz > range * range || Math.abs(dy) > rangeY;
			});
		}

		for (int x = -range; x <= range; x++) {
			for (int y = -rangeY; y <= rangeY; y++) {
				for (int z = -range; z <= range; z++) {
					if (x * x + z * z > range * range) continue;
					BlockPos pos = origin.offset(x, y, z);
					BlockState state = player.level().getBlockState(pos);
					if (isOre(state)) foundOres.add(pos.immutable());
					if (scannerMode && isChest(state)) foundChests.add(pos.immutable());
				}
			}
		}
	}

	private static void renderOutlines(WorldRenderContext context) {
		if (foundOres.isEmpty() && foundChests.isEmpty()) return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) return;
		if (mc.level.getGameTime() >= activeUntil) return;

		Vec3 cam = context.camera().getPosition();
		Matrix4f matrix = context.matrixStack().last().pose();

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableDepthTest();
		RenderSystem.setShader(GameRenderer::getPositionColorShader);
		RenderSystem.lineWidth(2.5f);

		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder buffer = tesselator.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);

		for (BlockPos pos : foundOres) {
			float[] c = getColor(mc.level.getBlockState(pos));
			drawBox(buffer, matrix, pos, cam, c[0], c[1], c[2], c[3]);
		}
		if (scannerMode) {
			for (BlockPos pos : foundChests) {
				drawBox(buffer, matrix, pos, cam, CHEST[0], CHEST[1], CHEST[2], CHEST[3]);
			}
		}

		BufferUploader.drawWithShader(buffer.buildOrThrow());
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.lineWidth(1.0f);
	}

	private static void drawBox(BufferBuilder buffer, Matrix4f matrix, BlockPos pos, Vec3 cam,
								float r, float g, float b, float a) {
		float x1 = (float) (pos.getX() - cam.x);
		float y1 = (float) (pos.getY() - cam.y);
		float z1 = (float) (pos.getZ() - cam.z);
		float x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;
		line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
		line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
		line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
		line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
		line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
		line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
		line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
		line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
	}

	private static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float bl, float a) {
		b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
		b.addVertex(m, x2, y2, z2).setColor(r, g, bl, a);
	}

	private static float[] getColor(BlockState state) {
		if (state.getBlock() == com.speleologist.block.ModBlocks.PHOTON_ORE) return PHOTON;
		if (state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE)) return DIAMOND;
		if (state.is(Blocks.IRON_ORE) || state.is(Blocks.DEEPSLATE_IRON_ORE)) return IRON;
		if (state.is(Blocks.GOLD_ORE) || state.is(Blocks.DEEPSLATE_GOLD_ORE) || state.is(Blocks.NETHER_GOLD_ORE)) return GOLD;
		if (state.is(Blocks.REDSTONE_ORE) || state.is(Blocks.DEEPSLATE_REDSTONE_ORE)) return REDSTONE;
		if (state.is(Blocks.EMERALD_ORE) || state.is(Blocks.DEEPSLATE_EMERALD_ORE)) return EMERALD;
		if (state.is(Blocks.LAPIS_ORE) || state.is(Blocks.DEEPSLATE_LAPIS_ORE)) return LAPIS;
		if (state.is(Blocks.COAL_ORE) || state.is(Blocks.DEEPSLATE_COAL_ORE)) return COAL;
		if (state.is(Blocks.COPPER_ORE) || state.is(Blocks.DEEPSLATE_COPPER_ORE)) return COPPER;
		if (state.is(Blocks.ANCIENT_DEBRIS)) return ANCIENT;
		return WHITE;
	}

	private static boolean isOre(BlockState state) {
		if (state.is(Blocks.COAL_ORE) || state.is(Blocks.DEEPSLATE_COAL_ORE) ||
			state.is(Blocks.IRON_ORE) || state.is(Blocks.DEEPSLATE_IRON_ORE) ||
			state.is(Blocks.COPPER_ORE) || state.is(Blocks.DEEPSLATE_COPPER_ORE) ||
			state.is(Blocks.GOLD_ORE) || state.is(Blocks.DEEPSLATE_GOLD_ORE) ||
			state.is(Blocks.REDSTONE_ORE) || state.is(Blocks.DEEPSLATE_REDSTONE_ORE) ||
			state.is(Blocks.EMERALD_ORE) || state.is(Blocks.DEEPSLATE_EMERALD_ORE) ||
			state.is(Blocks.LAPIS_ORE) || state.is(Blocks.DEEPSLATE_LAPIS_ORE) ||
			state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE) ||
			state.is(Blocks.NETHER_GOLD_ORE) || state.is(Blocks.NETHER_QUARTZ_ORE) ||
			state.is(Blocks.ANCIENT_DEBRIS) || state.is(Blocks.GILDED_BLACKSTONE)) return true;
		return state.getBlock() == com.speleologist.block.ModBlocks.PHOTON_ORE;
	}

	private static boolean isChest(BlockState state) {
		return state.is(Blocks.CHEST) || state.is(Blocks.TRAPPED_CHEST) ||
			   state.is(Blocks.BARREL) || state.is(Blocks.ENDER_CHEST) || state.is(BlockTags.SHULKER_BOXES);
	}
}
