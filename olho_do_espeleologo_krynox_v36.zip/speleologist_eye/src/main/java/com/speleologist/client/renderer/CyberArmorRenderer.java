package com.speleologist.client.renderer;

import com.speleologist.item.CyberArmorItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

public class CyberArmorRenderer<T extends CyberArmorItem> extends GeoArmorRenderer<T> {
	public CyberArmorRenderer() {
		super(new GeoModel<T>() {
			private String piece(T animatable) {
				ArmorItem.Type type = animatable.getType();
				return switch (type) {
					case HELMET -> "cyber_helmet";
					case CHESTPLATE -> "cyber_chestplate";
					case LEGGINGS -> "cyber_leggings";
					case BOOTS -> "cyber_boots";
					default -> "cyber_chestplate";
				};
			}

			@Override
			public ResourceLocation getModelResource(T animatable) {
				String p = piece(animatable);
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "geo/armor/" + p + ".geo.json");
			}

			@Override
			public ResourceLocation getTextureResource(T animatable) {
				String p = piece(animatable);
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "textures/armor/" + p + ".png");
			}

			@Override
			public ResourceLocation getAnimationResource(T animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "animations/armor/cyber_armor.animation.json");
			}
		});
	}
}
