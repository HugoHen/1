package com.speleologist.block;

import com.mojang.serialization.MapCodec;
import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

public class AdvancedCraftingTableBlock extends BaseEntityBlock {
	public static final MapCodec<AdvancedCraftingTableBlock> CODEC = simpleCodec(AdvancedCraftingTableBlock::new);

	public AdvancedCraftingTableBlock(Properties properties) {
		super(properties);
	}

	public AdvancedCraftingTableBlock() {
		super(BlockBehaviour.Properties.of()
				.mapColor(MapColor.COLOR_CYAN)
				.instrument(NoteBlockInstrument.BASS)
				.strength(2.5f)
				.sound(SoundType.METAL)
				.noOcclusion());
	}

	@Override
	protected MapCodec<? extends BaseEntityBlock> codec() {
		return CODEC;
	}

	@Nullable
	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new AdvancedCraftingTableBlockEntity(pos, state);
	}

	@Override
	protected RenderShape getRenderShape(BlockState state) {
		// Model is drawn by GeoBlockRenderer, not the JSON block model
		return RenderShape.ENTITYBLOCK_ANIMATED;
	}

	@Override
	protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
		return true;
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide) {
			return InteractionResult.SUCCESS;
		}
		player.openMenu(state.getMenuProvider(level, pos));
		return InteractionResult.CONSUME;
	}

	@Override
	protected MenuProvider getMenuProvider(BlockState state, Level level, BlockPos pos) {
		return new SimpleMenuProvider(
				(id, inv, player) -> new AdvancedCraftingMenu(id, inv, ContainerLevelAccess.create(level, pos)),
				Component.translatable("container.olho_do_espeleologo.advanced_crafting")
		);
	}
}
