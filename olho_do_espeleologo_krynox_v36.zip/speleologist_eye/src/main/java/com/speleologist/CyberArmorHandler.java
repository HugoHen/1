package com.speleologist;

import com.speleologist.item.CyberArmorItem;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;

public final class CyberArmorHandler {
	/** Vanilla creative fly speed is ~0.05; 3x = 0.15 */
	private static final float FLY_SPEED_3X = 0.15f;
	private static final String TAG = "krynox_cyber_flight";

	private CyberArmorHandler() {}

	public static boolean hasFullSet(Player player) {
		return player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof CyberArmorItem;
	}

	public static void register() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof Player player && hasFullSet(player)) {
				return false;
			}
			return true;
		});
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
			if (entity instanceof Player player && hasFullSet(player)) {
				player.setHealth(player.getMaxHealth());
				return false;
			}
			return true;
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				boolean full = hasFullSet(player);
				if (full) {
					player.setHealth(player.getMaxHealth());
					player.getFoodData().setFoodLevel(20);
					player.getFoodData().setSaturation(20f);
					player.clearFire();
					player.setAirSupply(player.getMaxAirSupply());
					player.fallDistance = 0;
					player.removeEffect(MobEffects.POISON);
					player.removeEffect(MobEffects.WITHER);
					player.removeEffect(MobEffects.HARM);
					player.removeEffect(MobEffects.HUNGER);
					player.removeEffect(MobEffects.LEVITATION);
					player.removeEffect(MobEffects.MOVEMENT_SLOWDOWN);
					player.removeEffect(MobEffects.DIG_SLOWDOWN);
					player.removeEffect(MobEffects.BLINDNESS);
					player.removeEffect(MobEffects.CONFUSION);
					player.removeEffect(MobEffects.WEAKNESS);
					if (player.getY() < player.level().getMinBuildHeight() - 16) {
						player.teleportTo(player.getX(), Math.max(player.level().getSeaLevel() + 10, 80), player.getZ());
					}
					player.getAbilities().mayfly = true;
					player.getAbilities().setFlyingSpeed(FLY_SPEED_3X);
					player.getPersistentData().putBoolean(TAG, true);
					player.onUpdateAbilities();
				} else if (player.getPersistentData().getBoolean(TAG)) {
					player.getPersistentData().putBoolean(TAG, false);
					if (!player.isCreative() && !player.isSpectator()) {
						player.getAbilities().mayfly = false;
						player.getAbilities().flying = false;
						player.getAbilities().setFlyingSpeed(0.05f);
						player.onUpdateAbilities();
					}
				}
			}
		});
	}
}
