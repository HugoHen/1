package com.speleologist;

import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.levelgen.GenerationStep;

public class WorldGen {
	public static void register() {
		ResourceKey<net.minecraft.world.level.levelgen.placement.PlacedFeature> key =
				ResourceKey.create(Registries.PLACED_FEATURE,
						ResourceLocation.fromNamespaceAndPath(SpeleologistMod.MOD_ID, "photon_ore"));

		BiomeModifications.addFeature(
				BiomeSelectors.foundInOverworld(),
				GenerationStep.Decoration.UNDERGROUND_ORES,
				key
		);
	}
}
