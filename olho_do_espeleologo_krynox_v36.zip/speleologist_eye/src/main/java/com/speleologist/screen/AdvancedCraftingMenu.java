package com.speleologist.screen;

import com.speleologist.item.ModItems;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class AdvancedCraftingMenu extends AbstractContainerMenu {
	public static final int GRID = 5;
	public static final int GRID_SIZE = 25;

	private final CraftingContainer craftSlots;
	private final ResultContainer resultSlots = new ResultContainer();
	private final ContainerLevelAccess access;
	private final Level level;
	private final Player player;

	public AdvancedCraftingMenu(int syncId, Inventory playerInv) {
		this(syncId, playerInv, ContainerLevelAccess.NULL);
	}

	public AdvancedCraftingMenu(int syncId, Inventory playerInv, ContainerLevelAccess access) {
		super(ModMenuTypes.ADVANCED_CRAFTING, syncId);
		this.access = access;
		this.level = playerInv.player.level();
		this.player = playerInv.player;
		this.craftSlots = new CraftingContainer(this, GRID_SIZE);

		for (int row = 0; row < GRID; row++) {
			for (int col = 0; col < GRID; col++) {
				this.addSlot(new Slot(craftSlots, col + row * GRID, 12 + col * 18, 17 + row * 18));
			}
		}

		this.addSlot(new ResultSlot(resultSlots, 0, 147, 53));

		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, 120 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInv, col, 8 + col * 18, 178));
		}
	}

	/** Result slot: one craft per take, shift-click crafts multiple safely */
	private class ResultSlot extends Slot {
		public ResultSlot(Container container, int index, int x, int y) {
			super(container, index, x, y);
		}

		@Override
		public boolean mayPlace(ItemStack stack) {
			return false;
		}

		@Override
		public boolean mayPickup(Player player) {
			return hasItem();
		}

		@Override
		public void onTake(Player player, ItemStack stack) {
			consumeIngredientsOnce();
			updateResult();
			super.onTake(player, stack);
		}

		@Override
		public ItemStack remove(int amount) {
			// Always remove the full result stack once (don't partial-split weirdly)
			ItemStack current = getItem();
			if (current.isEmpty()) return ItemStack.EMPTY;
			ItemStack taken = current.copy();
			set(ItemStack.EMPTY);
			return taken;
		}
	}

	private void consumeIngredientsOnce() {
		craftSlots.silent = true;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) {
				s.shrink(1);
				if (s.isEmpty()) {
					craftSlots.items.set(i, ItemStack.EMPTY);
				}
			}
		}
		craftSlots.silent = false;
	}

	/** How many times the current recipe can be crafted */
	private int maxCraftsPossible() {
		ItemStack result = computeResult();
		if (result.isEmpty()) return 0;
		int max = 64;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) {
				max = Math.min(max, s.getCount());
			}
		}
		return Math.max(0, max);
	}

	@Override
	public void slotsChanged(Container container) {
		if (level == null || level.isClientSide) return;
		updateResult();
	}

	private void updateResult() {
		resultSlots.setItem(0, computeResult());
		broadcastChanges();
	}

	private ItemStack computeResult() {
		int f = filled();
		if (f == 25 && count(Items.REDSTONE_BLOCK) == 25)
			return new ItemStack(ModItems.COMPACTED_REDSTONE);
		if (f == 25 && count(ModItems.COMPACTED_REDSTONE) == 25)
			return new ItemStack(ModItems.REDSTONE_2X);
		if (f == 25 && count(ModItems.REDSTONE_2X) == 25)
			return new ItemStack(ModItems.REDSTONE_3X);
		if (f == 25 && count(ModItems.REDSTONE_3X) == 25)
			return new ItemStack(ModItems.REDSTONE_COMPLETE);
		if (f == 25 && count(Items.IRON_BLOCK) == 25)
			return new ItemStack(ModItems.COMPACTED_IRON);
		if (f == 25 && count(ModItems.COMPACTED_IRON) == 25)
			return new ItemStack(ModItems.IRON_2X);
		if (f == 25 && count(ModItems.IRON_2X) == 25)
			return new ItemStack(ModItems.IRON_3X);
		if (f == 25 && count(ModItems.IRON_3X) == 25)
			return new ItemStack(ModItems.IRON_COMPLETE);
		if (f == 25 && count(ModItems.PHOTON_FRAGMENT) == 25)
			return new ItemStack(ModItems.PHOTON_SEMI);
		if (f == 25 && count(ModItems.REDSTONE_COMPLETE) == 24
				&& craftSlots.getItem(12).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.REDSTONE_FLOW, 2);
		if (f == 25 && count(ModItems.IRON_COMPLETE) == 24
				&& craftSlots.getItem(12).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.IRON_FLOW, 2);
		if (isFirstFlowRecipe())
			return new ItemStack(ModItems.FIRST_FLOW, 1);
		return ItemStack.EMPTY;
	}

	private int count(Item item) {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			if (craftSlots.getItem(i).is(item)) n++;
		}
		return n;
	}

	private int filled() {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			if (!craftSlots.getItem(i).isEmpty()) n++;
		}
		return n;
	}

	private boolean isFirstFlowRecipe() {
		if (!craftSlots.getItem(12).is(Items.ENDER_EYE)) return false;
		int[] diamondSlots = {2, 6, 8, 10, 14, 16, 18, 22};
		for (int s : diamondSlots) {
			if (!craftSlots.getItem(s).is(Items.DIAMOND_BLOCK)) return false;
		}
		int rf = 0, irf = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			if (i == 12) continue;
			boolean isDiamond = false;
			for (int s : diamondSlots) if (s == i) { isDiamond = true; break; }
			if (isDiamond) continue;
			ItemStack st = craftSlots.getItem(i);
			if (st.is(ModItems.REDSTONE_FLOW)) rf++;
			else if (st.is(ModItems.IRON_FLOW)) irf++;
			else if (!st.isEmpty()) return false;
		}
		return rf == 8 && irf == 8;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;

		// Shift-click RESULT: craft multiple times, one result stack at a time into inventory
		if (index == GRID_SIZE) {
			ItemStack assembled = ItemStack.EMPTY;
			int crafts = 0;
			int maxCrafts = maxCraftsPossible();
			// Cap to avoid lag / dupe loops (max 64 crafts per shift-click)
			maxCrafts = Math.min(maxCrafts, 64);

			while (crafts < maxCrafts) {
				ItemStack result = computeResult();
				if (result.isEmpty()) break;

				ItemStack single = result.copy();
				// Try move one craft output into player inv
				if (!this.moveItemStackTo(single, GRID_SIZE + 1, this.slots.size(), true)) {
					break; // inventory full
				}
				consumeIngredientsOnce();
				crafts++;
				assembled = result.copy();
			}
			updateResult();
			return assembled;
		}

		ItemStack original = slot.getItem();
		ItemStack copy = original.copy();

		if (index > GRID_SIZE) {
			// player inv -> grid
			if (!this.moveItemStackTo(original, 0, GRID_SIZE, false)) {
				return ItemStack.EMPTY;
			}
		} else {
			// grid -> player inv
			if (!this.moveItemStackTo(original, GRID_SIZE + 1, this.slots.size(), false)) {
				return ItemStack.EMPTY;
			}
		}

		if (original.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
		else slot.setChanged();

		updateResult();
		return copy;
	}

	@Override
	public boolean stillValid(Player player) {
		return true;
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.access.execute((level, pos) -> this.clearContainer(player, craftSlots));
	}

	static class CraftingContainer implements Container {
		final NonNullList<ItemStack> items;
		private final AdvancedCraftingMenu menu;
		boolean silent = false;

		CraftingContainer(AdvancedCraftingMenu menu, int size) {
			this.menu = menu;
			this.items = NonNullList.withSize(size, ItemStack.EMPTY);
		}

		@Override public int getContainerSize() { return items.size(); }
		@Override public boolean isEmpty() {
			for (ItemStack s : items) if (!s.isEmpty()) return false;
			return true;
		}
		@Override public ItemStack getItem(int i) { return items.get(i); }
		@Override public ItemStack removeItem(int i, int count) {
			ItemStack r = ContainerHelper.removeItem(items, i, count);
			if (!r.isEmpty() && !silent) menu.slotsChanged(this);
			return r;
		}
		@Override public ItemStack removeItemNoUpdate(int i) {
			return ContainerHelper.takeItem(items, i);
		}
		@Override public void setItem(int i, ItemStack stack) {
			items.set(i, stack);
			if (!silent) menu.slotsChanged(this);
		}
		@Override public void setChanged() {
			if (!silent) menu.slotsChanged(this);
		}
		@Override public boolean stillValid(Player player) { return true; }
		@Override public void clearContent() { items.clear(); }
	}
}
