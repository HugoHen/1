package com.speleologist.screen;

import com.speleologist.SpeleologistMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;

public class ModMenuTypes {
	public static final MenuType<AdvancedCraftingMenu> ADVANCED_CRAFTING =
			new MenuType<>(AdvancedCraftingMenu::new, FeatureFlags.VANILLA_SET);

	public static void register() {
		Registry.register(BuiltInRegistries.MENU, SpeleologistMod.id("advanced_crafting"), ADVANCED_CRAFTING);
	}
}
