package com.speleologist;
import net.minecraft.world.level.block.Block;

import com.speleologist.item.CyberScannerItem;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class FortuneHandler {
	// Simple flag - in a full version this would be synced from the activation
	public static boolean scannerActive = false;
	public static long scannerUntil = 0;

	public static void register() {
		PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
			if (world.isClientSide || !(player instanceof ServerPlayer serverPlayer)) return true;

			if (world.getGameTime() < scannerUntil && isHoldingScanner(serverPlayer)) {
				// Apply temporary Fortune-like extra drops for ore blocks
				if (isOreBlock(state)) {
					// We let the break happen normally; extra drops can be added in AFTER
				}
			}
			return true;
		});

		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (world.isClientSide || !(player instanceof ServerPlayer) || !(world instanceof ServerLevel serverLevel)) return;

			if (world.getGameTime() < scannerUntil && isHoldingScanner(player) && isOreBlock(state)) {
				// Drop extra items to simulate high Fortune
				ItemStack tool = player.getMainHandItem();
				LootParams.Builder builder = new LootParams.Builder(serverLevel)
						.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
						.withParameter(LootContextParams.TOOL, tool)
						.withOptionalParameter(LootContextParams.THIS_ENTITY, player);

				List<ItemStack> drops = state.getDrops(builder);
				// Drop extra copies (simulating high fortune)
				for (ItemStack drop : drops) {
					if (!drop.isEmpty()) {
						ItemStack extra = drop.copy();
						extra.setCount(Math.min(64, drop.getCount() * 4)); // strong bonus
						Block.popResource(world, pos, extra);
					}
				}
			}
		});
	}

	private static boolean isHoldingScanner(net.minecraft.world.entity.player.Player player) {
		return player.getMainHandItem().getItem() instanceof CyberScannerItem
				|| player.getOffhandItem().getItem() instanceof CyberScannerItem;
	}

	private static boolean isOreBlock(BlockState state) {
		String name = state.getBlock().getDescriptionId().toLowerCase();
		return name.contains("ore") || name.contains("debris") || name.contains("photon");
	}
}
