package com.speleologist.item;

import com.speleologist.SpeleologistMod;
import net.minecraft.Util;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;
import java.util.List;

public final class CyberArmorMaterial {
	public static final Holder<ArmorMaterial> CYBER = register();

	private static Holder<ArmorMaterial> register() {
		EnumMap<ArmorItem.Type, Integer> defense = Util.make(new EnumMap<>(ArmorItem.Type.class), m -> {
			m.put(ArmorItem.Type.BOOTS, 4);
			m.put(ArmorItem.Type.LEGGINGS, 7);
			m.put(ArmorItem.Type.CHESTPLATE, 9);
			m.put(ArmorItem.Type.HELMET, 4);
			m.put(ArmorItem.Type.BODY, 11);
		});
		ArmorMaterial mat = new ArmorMaterial(
				defense,
				20,
				SoundEvents.ARMOR_EQUIP_NETHERITE,
				() -> Ingredient.of(ModItems.PHOTON_COMPLETE),
				List.of(new ArmorMaterial.Layer(SpeleologistMod.id("cyber"))),
				3.0f,
				0.15f
		);
		return Registry.registerForHolder(BuiltInRegistries.ARMOR_MATERIAL, SpeleologistMod.id("cyber"), mat);
	}

	private CyberArmorMaterial() {}
}
