package com.speleologist.item;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;

public class PhotonFragmentItem extends Item {
	public PhotonFragmentItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}

	@Override
	public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
		if (level.isClientSide) return;
		if (!(entity instanceof Player player)) return;
		// Blind while the fragment is the held main-hand or off-hand item
		ItemStack main = player.getMainHandItem();
		ItemStack off = player.getOffhandItem();
		boolean holding = main.getItem() == this || off.getItem() == this;
		if (holding) {
			// short duration, refreshed every tick while held — removes quickly when not held
			player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0, true, false, true));
		}
	}
}
