package com.speleologist.item;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.function.Consumer;

public class CyberArmorItem extends ArmorItem implements GeoItem {
	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

	public CyberArmorItem(Type type) {
		super(CyberArmorMaterial.CYBER, type, new Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant().durability(type.getDurability(40)));
	}

	@Override
	public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
		consumer.accept(new GeoRenderProvider() {
			private com.speleologist.client.renderer.CyberArmorRenderer<?> armorRenderer;
			private com.speleologist.client.renderer.CyberArmorItemRenderer itemRenderer;

			@Override
			public <T extends LivingEntity> HumanoidModel<?> getGeoArmorRenderer(@Nullable T livingEntity, ItemStack itemStack, EquipmentSlot equipmentSlot, HumanoidModel<T> original) {
				if (this.armorRenderer == null) {
					this.armorRenderer = new com.speleologist.client.renderer.CyberArmorRenderer<>();
				}
				return this.armorRenderer;
			}

			@Override
			public BlockEntityWithoutLevelRenderer getGeoItemRenderer() {
				if (this.itemRenderer == null) {
					this.itemRenderer = new com.speleologist.client.renderer.CyberArmorItemRenderer();
				}
				return this.itemRenderer;
			}
		});
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return cache;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		tooltip.add(Component.translatable("item.olho_do_espeleologo.cyber_armor.desc"));
	}
}
