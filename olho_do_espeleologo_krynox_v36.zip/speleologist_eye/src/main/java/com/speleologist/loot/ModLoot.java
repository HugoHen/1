package com.speleologist.loot;

import com.speleologist.item.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.SetItemCountFunction;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

public class ModLoot {
	public static void register() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			String path = key.location().getPath();

			boolean isTargetChest =
					path.equals("chests/abandoned_mineshaft") ||
					path.equals("chests/ancient_city") ||
					path.equals("chests/end_city_treasure") ||
					path.equals("chests/simple_dungeon");

			if (isTargetChest) {
				LootPool.Builder pool = LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1))
						.when(LootItemRandomChanceCondition.randomChance(0.06f))
						.add(LootItem.lootTableItem(ModItems.SPELEOLOGIST_EYE)
								.apply(SetItemCountFunction.setCount(ConstantValue.exactly(1))));
				tableBuilder.pool(pool.build());
			}

			if (path.equals("gameplay/fishing/treasure") || path.equals("gameplay/fishing")) {
				LootPool.Builder pool = LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1))
						.when(LootItemRandomChanceCondition.randomChance(0.03f))
						.add(LootItem.lootTableItem(ModItems.SPELEOLOGIST_EYE)
								.apply(SetItemCountFunction.setCount(ConstantValue.exactly(1))));
				tableBuilder.pool(pool.build());
			}
		});
	}
}
