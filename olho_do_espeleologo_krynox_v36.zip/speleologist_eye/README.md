# Speleologist's Eye + Cyber Scanner – Fabric 1.21.1
Author: krynox

## Textures applied
- Advanced Crafting Table (tech top)
- Speleologist's Eye (animated)
- Photon Ore (purple veins)
- Compacted materials (pattern recolored)
- Cyber Scanner (3D model in hand)

## Fixes
- Eye/Scanner no longer auto-activate continuously
- Outlines stay fixed until time ends / block broken / out of range
- 5x5 crafting updates result when items placed
- Photon Ore is 3D in hand

## 5x5 recipes
- 25 Photon Fragments → Semi-Complete Photon
- 25 Redstone Blocks → Compacted Redstone
- 25 Iron Blocks → Compacted Iron

## Build
./gradlew build
