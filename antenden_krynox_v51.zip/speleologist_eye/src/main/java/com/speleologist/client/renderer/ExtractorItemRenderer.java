package com.speleologist.client.renderer;

import com.speleologist.item.ExtractorItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class ExtractorItemRenderer extends GeoItemRenderer<ExtractorItem> {
	public ExtractorItemRenderer() {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(ExtractorItem a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "geo/item/extractor.geo.json");
			}
			@Override
			public ResourceLocation getTextureResource(ExtractorItem a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "textures/block/extractor.png");
			}
			@Override
			public ResourceLocation getAnimationResource(ExtractorItem a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "animations/block/extractor.animation.json");
			}
		});
	}
}
