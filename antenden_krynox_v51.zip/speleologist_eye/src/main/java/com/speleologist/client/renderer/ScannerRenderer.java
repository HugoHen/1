package com.speleologist.client.renderer;

import com.speleologist.item.CyberScannerItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class ScannerRenderer extends GeoItemRenderer<CyberScannerItem> {
	public ScannerRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("antenden", "cyber_scanner")));
	}
}
