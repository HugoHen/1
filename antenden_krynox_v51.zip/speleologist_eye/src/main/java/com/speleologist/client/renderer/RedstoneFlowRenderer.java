package com.speleologist.client.renderer;

import com.speleologist.item.RedstoneFlowItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class RedstoneFlowRenderer extends GeoItemRenderer<RedstoneFlowItem> {
	public RedstoneFlowRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("antenden", "redstone_flow")));
	}
}
