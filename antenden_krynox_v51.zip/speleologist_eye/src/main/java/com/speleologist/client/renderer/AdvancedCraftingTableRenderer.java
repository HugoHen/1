package com.speleologist.client.renderer;

import com.speleologist.block.AdvancedCraftingTableBlockEntity;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class AdvancedCraftingTableRenderer extends GeoBlockRenderer<AdvancedCraftingTableBlockEntity> {
	public AdvancedCraftingTableRenderer(BlockEntityRendererProvider.Context context) {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(AdvancedCraftingTableBlockEntity animatable) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "geo/block/advanced_crafting_table.geo.json");
			}

			@Override
			public ResourceLocation getTextureResource(AdvancedCraftingTableBlockEntity animatable) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "textures/block/advanced_crafting_table.png");
			}

			@Override
			public ResourceLocation getAnimationResource(AdvancedCraftingTableBlockEntity animatable) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "animations/block/advanced_crafting_table.animation.json");
			}
		});
	}
}
