package com.speleologist.client.screen;

import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** 7x7 crafting GUI — slots aligned with drawn grid. */
public class AdvancedCraftingScreen extends AbstractContainerScreen<AdvancedCraftingMenu> {
	private static final int BG = 0xFFC6C6C6;
	private static final int SLOT = 0xFF8B8B8B;
	private static final int SLOT_INNER = 0xFF373737;
	private static final int HIGHLIGHT = 0xFFFFFFFF;
	private static final int SHADOW = 0xFF555555;
	private static final int ARROW = 0xFF555555;

	public AdvancedCraftingScreen(AdvancedCraftingMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		// 7*18=126 + padding; inv 3*18+hotbar
		this.imageWidth = 176;
		this.imageHeight = 240;
		this.titleLabelX = 8;
		this.titleLabelY = 6;
		this.inventoryLabelX = 8;
		this.inventoryLabelY = 144;
	}

	@Override
	protected void renderBg(GuiGraphics g, float delta, int mouseX, int mouseY) {
		int x = this.leftPos;
		int y = this.topPos;

		// Panel
		g.fill(x, y, x + imageWidth, y + imageHeight, BG);
		g.fill(x, y, x + imageWidth, y + 1, HIGHLIGHT);
		g.fill(x, y, x + 1, y + imageHeight, HIGHLIGHT);
		g.fill(x + imageWidth - 1, y, x + imageWidth, y + imageHeight, SHADOW);
		g.fill(x, y + imageHeight - 1, x + imageWidth, y + imageHeight, SHADOW);

		// 7x7 craft grid — MUST match Menu slot positions (8+col*18, 18+row*18)
		for (int row = 0; row < 7; row++) {
			for (int col = 0; col < 7; col++) {
				drawSlot(g, x + 7 + col * 18, y + 17 + row * 18);
			}
		}

		// Arrow
		int ax = x + 136;
		int ay = y + 78;
		g.fill(ax, ay + 4, ax + 10, ay + 8, ARROW);
		g.fill(ax + 8, ay + 1, ax + 12, ay + 11, ARROW);
		g.fill(ax + 10, ay + 3, ax + 14, ay + 9, ARROW);

		// Result — match Menu (152, 72) → screen coords leftPos+151, topPos+71
		drawSlot(g, x + 151, y + 71);

		// Player inv — match Menu invY=156 → 155, hotbar 214
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				drawSlot(g, x + 7 + col * 18, y + 155 + row * 18);
			}
		}
		for (int col = 0; col < 9; col++) {
			drawSlot(g, x + 7 + col * 18, y + 213);
		}
	}

	private void drawSlot(GuiGraphics g, int sx, int sy) {
		g.fill(sx, sy, sx + 18, sy + 18, SLOT);
		g.fill(sx + 1, sy + 1, sx + 17, sy + 17, SLOT_INNER);
		g.fill(sx, sy, sx + 18, sy + 1, SHADOW);
		g.fill(sx, sy, sx + 1, sy + 18, SHADOW);
		g.fill(sx + 17, sy, sx + 18, sy + 18, HIGHLIGHT);
		g.fill(sx, sy + 17, sx + 18, sy + 18, HIGHLIGHT);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		renderBackground(graphics, mouseX, mouseY, delta);
		super.render(graphics, mouseX, mouseY, delta);
		renderTooltip(graphics, mouseX, mouseY);
	}

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
		graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 0x404040, false);
	}
}
