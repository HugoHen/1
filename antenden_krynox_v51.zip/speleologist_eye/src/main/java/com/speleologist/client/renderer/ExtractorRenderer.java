package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.speleologist.block.ExtractorBlock;
import com.speleologist.block.ExtractorBlockEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class ExtractorRenderer extends GeoBlockRenderer<ExtractorBlockEntity> {
	public ExtractorRenderer(BlockEntityRendererProvider.Context context) {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "geo/block/extractor.geo.json");
			}
			@Override
			public ResourceLocation getTextureResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "textures/block/extractor.png");
			}
			@Override
			public ResourceLocation getAnimationResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "animations/block/extractor.animation.json");
			}
		});
	}

	@Override
	public void render(ExtractorBlockEntity animatable, float partialTick, PoseStack poseStack,
			MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		BlockState state = animatable.getBlockState();
		Direction facing = state.hasProperty(ExtractorBlock.FACING)
				? state.getValue(ExtractorBlock.FACING) : Direction.NORTH;
		poseStack.pushPose();
		// Rotate model so front follows facing
		float yRot = switch (facing) {
			case SOUTH -> 180f;
			case WEST -> 90f;
			case EAST -> -90f;
			default -> 0f;
		};
		poseStack.translate(0.5, 0, 0.5);
		poseStack.mulPose(Axis.YP.rotationDegrees(yRot));
		poseStack.translate(-0.5, 0, -0.5);
		super.render(animatable, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
		poseStack.popPose();
	}
}
