package com.speleologist.client.renderer;

import com.speleologist.item.IronFlowItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class IronFlowRenderer extends GeoItemRenderer<IronFlowItem> {
	public IronFlowRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("antenden", "iron_flow")));
	}
}
