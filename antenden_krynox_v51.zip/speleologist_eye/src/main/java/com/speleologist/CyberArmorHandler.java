package com.speleologist;

import com.speleologist.item.CyberArmorItem;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;

public final class CyberArmorHandler {
	private static final float FLY_SPEED_3X = 0.15f;
	private static final float VANILLA_FLY = 0.05f;
	private static final String TAG = "krynox_cyber_flight";

	private CyberArmorHandler() {}

	public static boolean hasFullSet(Player player) {
		return player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.CHEST).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.LEGS).getItem() instanceof CyberArmorItem
				&& player.getItemBySlot(EquipmentSlot.FEET).getItem() instanceof CyberArmorItem;
	}

	public static void register() {
		// Immortal while full set — including void damage, but NO teleport
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			if (entity instanceof Player player && hasFullSet(player)) {
				return false; // no damage (void, mobs, etc.)
			}
			return true;
		});
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
			if (entity instanceof Player player && hasFullSet(player)) {
				player.setHealth(player.getMaxHealth());
				return false;
			}
			return true;
		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {
			for (ServerPlayer player : server.getPlayerList().getPlayers()) {
				boolean full = hasFullSet(player);
				if (full) {
					player.setHealth(player.getMaxHealth());
					player.getFoodData().setFoodLevel(20);
					player.getFoodData().setSaturation(20f);
					player.clearFire();
					player.setAirSupply(player.getMaxAirSupply());
					player.fallDistance = 0;
					// Speed 6 (amplifier 5)
					player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 5, false, false, true));
					player.getAbilities().mayfly = true;
					player.getAbilities().setFlyingSpeed(FLY_SPEED_3X);
					player.getPersistentData().putBoolean(TAG, true);
					player.onUpdateAbilities();
					// NOTE: no void teleport — player falls, takes no damage
				} else if (player.getPersistentData().getBoolean(TAG)) {
					// Remove ALL armor-granted effects
					player.getPersistentData().putBoolean(TAG, false);
					player.removeEffect(MobEffects.MOVEMENT_SPEED);
					// Flight: only strip if not creative/spectator
					if (player.isCreative() || player.isSpectator()) {
						player.getAbilities().mayfly = true;
						player.getAbilities().setFlyingSpeed(VANILLA_FLY);
					} else {
						player.getAbilities().mayfly = false;
						player.getAbilities().flying = false;
						player.getAbilities().setFlyingSpeed(VANILLA_FLY);
					}
					player.onUpdateAbilities();
				}
			}
		});
	}
}
