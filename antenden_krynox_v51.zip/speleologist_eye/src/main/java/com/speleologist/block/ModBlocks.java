package com.speleologist.block;

import com.speleologist.SpeleologistMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.util.valueproviders.UniformInt;

public class ModBlocks {
	public static final Block PHOTON_ORE = new DropExperienceBlock(
			UniformInt.of(2, 5),
			BlockBehaviour.Properties.ofFullCopy(Blocks.DIAMOND_ORE)
					.mapColor(MapColor.COLOR_PURPLE)
					.instrument(NoteBlockInstrument.BASEDRUM)
					.requiresCorrectToolForDrops()
					.strength(8.0f, 8.0f)
	);

	public static final Block ADVANCED_CRAFTING_TABLE = new AdvancedCraftingTableBlock();
	public static final Block EXTRACTOR = new ExtractorBlock();

	// Material blocks (all sides same texture)
	public static final Block COMPACTED_REDSTONE = metal(MapColor.COLOR_RED);
	public static final Block REDSTONE_2X = metal(MapColor.COLOR_RED);
	public static final Block REDSTONE_3X = metal(MapColor.COLOR_RED);
	public static final Block REDSTONE_COMPLETE = metal(MapColor.COLOR_RED);
	public static final Block COMPACTED_IRON = metal(MapColor.METAL);
	public static final Block IRON_2X = metal(MapColor.METAL);
	public static final Block IRON_3X = metal(MapColor.METAL);
	public static final Block IRON_COMPLETE = metal(MapColor.METAL);

	private static Block metal(MapColor color) {
		return new Block(BlockBehaviour.Properties.of()
				.mapColor(color)
				.instrument(NoteBlockInstrument.IRON_XYLOPHONE)
				.requiresCorrectToolForDrops()
				.strength(5.0f, 6.0f)
				.sound(SoundType.METAL));
	}

	public static void register() {
		reg("photon_ore", PHOTON_ORE);
		reg("advanced_crafting_table", ADVANCED_CRAFTING_TABLE);
		reg("extractor", EXTRACTOR);
		reg("compacted_redstone", COMPACTED_REDSTONE);
		reg("redstone_2x", REDSTONE_2X);
		reg("redstone_3x", REDSTONE_3X);
		reg("redstone_complete", REDSTONE_COMPLETE);
		reg("compacted_iron", COMPACTED_IRON);
		reg("iron_2x", IRON_2X);
		reg("iron_3x", IRON_3X);
		reg("iron_complete", IRON_COMPLETE);
	}

	private static void reg(String id, Block block) {
		Registry.register(BuiltInRegistries.BLOCK, SpeleologistMod.id(id), block);
	}
}
