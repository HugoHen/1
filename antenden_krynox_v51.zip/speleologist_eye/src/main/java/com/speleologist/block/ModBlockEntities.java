package com.speleologist.block;

import com.speleologist.SpeleologistMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;

public final class ModBlockEntities {
	public static final BlockEntityType<AdvancedCraftingTableBlockEntity> ADVANCED_CRAFTING_TABLE =
			BlockEntityType.Builder.of(AdvancedCraftingTableBlockEntity::new, ModBlocks.ADVANCED_CRAFTING_TABLE).build(null);

	public static final BlockEntityType<ExtractorBlockEntity> EXTRACTOR =
			BlockEntityType.Builder.of(ExtractorBlockEntity::new, ModBlocks.EXTRACTOR).build(null);

	private ModBlockEntities() {}

	public static void register() {
		Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,
				SpeleologistMod.id("advanced_crafting_table"), ADVANCED_CRAFTING_TABLE);
		Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE,
				SpeleologistMod.id("extractor"), EXTRACTOR);
	}
}
