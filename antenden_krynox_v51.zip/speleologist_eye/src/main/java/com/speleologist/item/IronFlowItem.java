package com.speleologist.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;

public class IronFlowItem extends Item {
	public IronFlowItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
