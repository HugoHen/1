package com.speleologist.item;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.function.Consumer;

public class CyberScannerItem extends Item implements GeoItem {
	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

	public CyberScannerItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
	}

	@Override
	public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
		consumer.accept(new GeoRenderProvider() {
			private com.speleologist.client.renderer.ScannerRenderer renderer;
			@Override
			public BlockEntityWithoutLevelRenderer getGeoItemRenderer() {
				if (renderer == null) renderer = new com.speleologist.client.renderer.ScannerRenderer();
				return renderer;
			}
		});
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		controllers.add(new AnimationController<>(this, "controller", 0, state -> {
			state.setAnimation(RawAnimation.begin().thenLoop("idle"));
			return PlayState.CONTINUE;
		}));
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return cache;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
			boolean hasFuel = false;
			for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
				ItemStack invStack = player.getInventory().getItem(i);
				if (invStack.is(Items.REDSTONE) && invStack.getCount() > 0) {
					invStack.shrink(1);
					hasFuel = true;
					break;
				}
			}
			if (!hasFuel) {
				serverPlayer.sendSystemMessage(Component.literal("§cNo Redstone fuel! Need Redstone Dust."));
				return InteractionResultHolder.fail(stack);
			}
			serverPlayer.sendSystemMessage(Component.literal("§bCyber Scanner activated! (3 min)"));
			com.speleologist.FortuneHandler.activateScanner(serverPlayer, 3 * 60 * 20L);
		}
		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		tooltip.add(Component.literal("§6Cyber Scanner"));
		tooltip.add(Component.literal("§7Reveals ores & chests §b40×40×30"));
		tooltip.add(Component.literal("§7Duration: §b3 min §8| §7Fuel: 1 Redstone"));
		tooltip.add(Component.literal("§8Ends if removed, death, or leave area"));
	}
}
