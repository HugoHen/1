package com.speleologist.item;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class SpeleologistEyeItem extends Item {
	public SpeleologistEyeItem(Properties properties, boolean unused) {
		super(properties);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);

		if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
			// Cost: hunger + half heart
			if (player.getHealth() <= 1.0f && player.getFoodData().getFoodLevel() <= 0) {
				serverPlayer.sendSystemMessage(Component.literal("§cNot enough health/hunger to use the Eye!"));
				return InteractionResultHolder.fail(stack);
			}

			// Apply cost
			player.hurt(player.damageSources().magic(), 1.0f); // half heart = 1.0 damage
			player.getFoodData().setFoodLevel(Math.max(0, player.getFoodData().getFoodLevel() - 2));

			// Cooldown 2 minutes
			player.getCooldowns().addCooldown(this, 2 * 60 * 20);

			serverPlayer.sendSystemMessage(Component.literal("§aSpeleologist's Eye activated! (10s)"));
		}

		return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		tooltip.add(Component.literal("§7Reveals ores §a12 blocks§7 around activation point"));
		tooltip.add(Component.literal("§7Duration: §a10s §8| §7Cooldown applies"));
		tooltip.add(Component.literal("§cCosts: Hunger + ½ Heart"));
		tooltip.add(Component.literal("§8Ends if removed, death, or leave area"));
	}
}
