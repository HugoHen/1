package com.speleologist.compat;

import com.speleologist.SpeleologistMod;
import com.speleologist.item.ModItems;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ModEmiPlugin implements EmiPlugin {
	public static final ResourceLocation ID = SpeleologistMod.id("advanced_7x7");
	public static final EmiStack WORKSTATION = EmiStack.of(ModItems.ADVANCED_CRAFTING_TABLE);
	public static final EmiRecipeCategory CATEGORY = new EmiRecipeCategory(ID, WORKSTATION);
	private static final int GRID = 7;
	private static final int SIZE = 49;
	private static final int CENTER = 24;

	@Override
	public void register(EmiRegistry registry) {
		registry.addCategory(CATEGORY);
		registry.addWorkstation(CATEGORY, WORKSTATION);

		fill(registry, "compacted_redstone", EmiStack.of(Items.REDSTONE_BLOCK), EmiStack.of(ModItems.COMPACTED_REDSTONE));
		fill(registry, "redstone_2x", EmiStack.of(ModItems.COMPACTED_REDSTONE), EmiStack.of(ModItems.REDSTONE_2X));
		fill(registry, "redstone_3x", EmiStack.of(ModItems.REDSTONE_2X), EmiStack.of(ModItems.REDSTONE_3X));
		fill(registry, "redstone_complete", EmiStack.of(ModItems.REDSTONE_3X), EmiStack.of(ModItems.REDSTONE_COMPLETE));
		fill(registry, "compacted_iron", EmiStack.of(Items.IRON_BLOCK), EmiStack.of(ModItems.COMPACTED_IRON));
		fill(registry, "iron_2x", EmiStack.of(ModItems.COMPACTED_IRON), EmiStack.of(ModItems.IRON_2X));
		fill(registry, "iron_3x", EmiStack.of(ModItems.IRON_2X), EmiStack.of(ModItems.IRON_3X));
		fill(registry, "iron_complete", EmiStack.of(ModItems.IRON_3X), EmiStack.of(ModItems.IRON_COMPLETE));
		fill(registry, "photon_semi", EmiStack.of(ModItems.PHOTON_FRAGMENT), EmiStack.of(ModItems.PHOTON_SEMI));
		fill(registry, "photon_complete", EmiStack.of(ModItems.PHOTON_SEMI), EmiStack.of(ModItems.PHOTON_COMPLETE));

		List<EmiIngredient> rf = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.of(ModItems.REDSTONE_COMPLETE)));
		rf.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/redstone_flow"), rf, EmiStack.of(ModItems.REDSTONE_FLOW, 2)));

		List<EmiIngredient> irf = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.of(ModItems.IRON_COMPLETE)));
		irf.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/iron_flow"), irf, EmiStack.of(ModItems.IRON_FLOW, 2)));

		registry.addRecipe(new R(SpeleologistMod.id("emi/star"),
				patternFill(STAR, Map.of('N', Items.NETHER_STAR)), EmiStack.of(ModItems.STAR)));
		registry.addRecipe(new R(SpeleologistMod.id("emi/big_star"),
				patternFill(STAR, Map.of('N', ModItems.STAR)), EmiStack.of(ModItems.BIG_STAR)));
		registry.addRecipe(new R(SpeleologistMod.id("emi/the_first_star"),
				patternFill(STAR, Map.of('N', ModItems.BIG_STAR)), EmiStack.of(ModItems.THE_FIRST_STAR)));

		List<EmiIngredient> bv = emptyGrid();
		bv.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		bv.set(CENTER - 7, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER + 7, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER - 1, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER + 1, EmiStack.of(ModItems.PHOTON_COMPLETE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/black_vortex"), bv, EmiStack.of(ModItems.BLACK_VORTEX)));

		List<EmiIngredient> sc = emptyGrid();
		sc.set(CENTER, EmiStack.of(ModItems.BLACK_VORTEX));
		sc.set(0, EmiStack.of(Items.ENDER_EYE));
		sc.set(6, EmiStack.of(Items.ENDER_EYE));
		sc.set(42, EmiStack.of(Items.ENDER_EYE));
		sc.set(48, EmiStack.of(Items.ENDER_EYE));
		sc.set(3, EmiStack.of(ModItems.COMPACTED_IRON));
		sc.set(45, EmiStack.of(ModItems.COMPACTED_IRON));
		sc.set(21, EmiStack.of(ModItems.COMPACTED_REDSTONE));
		sc.set(27, EmiStack.of(ModItems.COMPACTED_REDSTONE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_scanner"), sc, EmiStack.of(ModItems.CYBER_SCANNER)));

		// Armor — same patterns as AdvancedCraftingMenu
		Map<Character, Item> armor = Map.of(
				'c', ModItems.CARAMEL_VORTEX,
				't', ModItems.THE_FIRST_STAR,
				'm', ModItems.FIRST_FLOW,
				'b', ModItems.BLACK_VORTEX,
				'e', ModItems.SPELEOLOGIST_EYE
		);
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_helmet"), patternFill(ARMOR_HELMET, armor), EmiStack.of(ModItems.CYBER_HELMET)));
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_chestplate"), patternFill(ARMOR_CHEST, armor), EmiStack.of(ModItems.CYBER_CHESTPLATE)));
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_leggings"), patternFill(ARMOR_LEGS, armor), EmiStack.of(ModItems.CYBER_LEGGINGS)));
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_boots"), patternFill(ARMOR_BOOTS, armor), EmiStack.of(ModItems.CYBER_BOOTS)));
	}

	private static final String[] STAR = {
			"  NNN  ",
			" NNNNN ",
			"NNNNNNN",
			"NNNNNNN",
			" NNNNN ",
			"  NNN  ",
			"   N   "
	};
	private static final String[] ARMOR_HELMET = {
			" ccccc ",
			"ccccccc",
			"ctccctc",
			"cmmcmmc",
			"ct b tc",
			"ccc ccc",
			" cc cc "
	};
	private static final String[] ARMOR_CHEST = {
			" cc cc ",
			"ccccccc",
			"cctmtcc",
			" cmemc ",
			" cbmbc ",
			" ctbtc ",
			"  ccc  "
	};
	private static final String[] ARMOR_LEGS = {
			"  tct  ",
			" tcbct ",
			"cbcccbc",
			"cmc cmc",
			"mtm mtm",
			"cmc cmc",
			" cc cc "
	};
	private static final String[] ARMOR_BOOTS = {
			"       ",
			" mcmcm ",
			" cbbbc ",
			" ccbcc ",
			" ccccc ",
			"cct tcc",
			"ctc ctc"
	};

	private List<EmiIngredient> emptyGrid() {
		return new ArrayList<>(Collections.nCopies(SIZE, EmiStack.EMPTY));
	}

	private List<EmiIngredient> patternFill(String[] pattern, Map<Character, ? extends Item> key) {
		List<EmiIngredient> list = emptyGrid();
		for (int r = 0; r < 7; r++) {
			for (int c = 0; c < 7; c++) {
				char ch = pattern[r].charAt(c);
				if (ch != ' ') {
					Item item = key.get(ch);
					if (item != null) list.set(r * 7 + c, EmiStack.of(item));
				}
			}
		}
		return list;
	}

	private void fill(EmiRegistry registry, String id, EmiStack input, EmiStack output) {
		List<EmiIngredient> inputs = new ArrayList<>(Collections.nCopies(SIZE, input));
		registry.addRecipe(new R(SpeleologistMod.id("emi/" + id), inputs, output));
	}

	static class R implements EmiRecipe {
		private final ResourceLocation id;
		private final List<EmiIngredient> inputs;
		private final EmiStack output;

		R(ResourceLocation id, List<EmiIngredient> inputs, EmiStack output) {
			this.id = id;
			this.inputs = inputs;
			this.output = output;
		}

		@Override public EmiRecipeCategory getCategory() { return CATEGORY; }
		@Override public ResourceLocation getId() { return id; }
		@Override public List<EmiIngredient> getInputs() { return inputs; }
		@Override public List<EmiStack> getOutputs() { return List.of(output); }
		@Override public int getDisplayWidth() { return 150; }
		@Override public int getDisplayHeight() { return 140; }

		@Override
		public void addWidgets(WidgetHolder widgets) {
			for (int i = 0; i < SIZE; i++) {
				int row = i / GRID;
				int col = i % GRID;
				widgets.addSlot(inputs.get(i), col * 18, row * 18);
			}
			widgets.addSlot(output, 132, 54).recipeContext(this);
		}
	}
}
