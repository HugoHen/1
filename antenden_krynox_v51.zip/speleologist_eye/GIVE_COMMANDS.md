# Antenden — /give

```
/give @p antenden:speleologist_eye
/give @p antenden:cyber_scanner
/give @p antenden:a_ultima
/give @p antenden:cyber_helmet
/give @p antenden:cyber_chestplate
/give @p antenden:cyber_leggings
/give @p antenden:cyber_boots
/give @p antenden:star
/give @p antenden:big_star
/give @p antenden:the_first_star
/give @p antenden:first_flow
/give @p antenden:redstone_flow
/give @p antenden:iron_flow
/give @p antenden:black_vortex
/give @p antenden:extractor
/give @p antenden:advanced_crafting_table
```
