package com.speleologist;

import com.speleologist.item.CyberScannerItem;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class FortuneHandler {
	public static boolean scannerActive = false;
	public static long scannerUntil = 0;
	public static BlockPos scannerOrigin = null;

	public static void register() {
		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			scannerActive = false;
			scannerUntil = 0;
			scannerOrigin = null;
		});

		PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
			if (world.isClientSide || !(player instanceof ServerPlayer) || !(world instanceof ServerLevel serverLevel)) return;

			if (!isScannerEffectValid(player, world.getGameTime())) return;
			if (!isOreBlock(state)) return;

			ItemStack tool = player.getMainHandItem();
			LootParams.Builder builder = new LootParams.Builder(serverLevel)
					.withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(pos))
					.withParameter(LootContextParams.TOOL, tool)
					.withOptionalParameter(LootContextParams.THIS_ENTITY, player);

			List<ItemStack> drops = state.getDrops(builder);
			for (ItemStack drop : drops) {
				if (!drop.isEmpty()) {
					ItemStack extra = drop.copy();
					extra.setCount(Math.min(64, drop.getCount() * 4));
					Block.popResource(world, pos, extra);
				}
			}
		});
	}

	/** Called when scanner is used successfully. */
	public static void activateScanner(ServerPlayer player, long durationTicks) {
		scannerActive = true;
		scannerUntil = player.level().getGameTime() + durationTicks;
		scannerOrigin = player.blockPosition().immutable();
	}

	public static void clearScanner() {
		scannerActive = false;
		scannerUntil = 0;
		scannerOrigin = null;
	}

	private static boolean isScannerEffectValid(net.minecraft.world.entity.player.Player player, long gameTime) {
		if (gameTime >= scannerUntil || !scannerActive) return false;
		if (player.isDeadOrDying()) {
			clearScanner();
			return false;
		}
		if (!hasScannerInInventory(player)) {
			clearScanner();
			return false;
		}
		if (scannerOrigin != null) {
			BlockPos p = player.blockPosition();
			int dx = p.getX() - scannerOrigin.getX();
			int dy = p.getY() - scannerOrigin.getY();
			int dz = p.getZ() - scannerOrigin.getZ();
			int range = 24;
			if (dx * dx + dz * dz > range * range || Math.abs(dy) > range) {
				clearScanner();
				return false;
			}
		}
		return true;
	}

	private static boolean hasScannerInInventory(net.minecraft.world.entity.player.Player player) {
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			if (player.getInventory().getItem(i).getItem() instanceof CyberScannerItem) return true;
		}
		return false;
	}

	private static boolean isOreBlock(BlockState state) {
		String name = state.getBlock().getDescriptionId().toLowerCase();
		return name.contains("ore") || name.contains("debris") || name.contains("photon");
	}
}
