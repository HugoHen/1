package com.speleologist.client.renderer;

import com.speleologist.item.CyberArmorItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoArmorRenderer;

public class CyberArmorRenderer<T extends CyberArmorItem> extends GeoArmorRenderer<T> {
	public CyberArmorRenderer() {
		super(new GeoModel<T>() {
			@Override
			public ResourceLocation getModelResource(T animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "geo/armor/cyber_armor.geo.json");
			}

			@Override
			public ResourceLocation getTextureResource(T animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "textures/armor/cyber_armor.png");
			}

			@Override
			public ResourceLocation getAnimationResource(T animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "animations/armor/cyber_armor.animation.json");
			}
		});
	}
}
