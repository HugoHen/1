package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.speleologist.item.AUltimaItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/**
 * Geo is built Y-up (shaft +Y, head at high Y). Grip between gold rings ≈ y 11.
 * Video reference: hands on brown shaft between gold bands; head forward-up away from body.
 */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	private static final float GRIP_Y = 11.0f;
	private static final float U = 1.0f / 16.0f;
	/** Model is ~69 units tall; shrink so tool length is reasonable in-world */
	private static final float MODEL_SCALE = 0.55f;

	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}

	@Override
	public void renderByItem(net.minecraft.world.item.ItemStack stack, ItemDisplayContext ctx,
			PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
		pose.pushPose();

		// Center grip at origin
		pose.translate(0, -GRIP_Y * U * MODEL_SCALE, 0);
		pose.scale(MODEL_SCALE, MODEL_SCALE, MODEL_SCALE);

		switch (ctx) {
			case THIRD_PERSON_RIGHT_HAND -> {
				// Match Blockbench side/back views: shaft out from hand, head up-forward
				pose.mulPose(Axis.XP.rotationDegrees(-20));
				pose.mulPose(Axis.YP.rotationDegrees(0));
				pose.translate(0.05, 0.15, 0.1);
			}
			case THIRD_PERSON_LEFT_HAND -> {
				pose.mulPose(Axis.XP.rotationDegrees(-20));
				pose.translate(-0.05, 0.15, 0.1);
			}
			case FIRST_PERSON_RIGHT_HAND -> {
				// Full tool in view: handle lower-right, head upper-center (not only shaft)
				pose.mulPose(Axis.XP.rotationDegrees(-15));
				pose.mulPose(Axis.YP.rotationDegrees(5));
				pose.translate(0.1, 0.2, -0.15);
			}
			case FIRST_PERSON_LEFT_HAND -> {
				pose.mulPose(Axis.XP.rotationDegrees(-15));
				pose.translate(-0.1, 0.2, -0.15);
			}
			case GROUND -> {
				pose.translate(0, 0.4, 0);
			}
			case FIXED -> {
				pose.mulPose(Axis.ZP.rotationDegrees(-35));
				pose.translate(0, 0.2, 0);
			}
			case GUI -> {
				pose.mulPose(Axis.XP.rotationDegrees(30));
				pose.mulPose(Axis.YP.rotationDegrees(45));
				pose.translate(0, 0.1, 0);
			}
			default -> {
			}
		}

		super.renderByItem(stack, ctx, pose, buffers, light, overlay);
		pose.popPose();
	}
}
