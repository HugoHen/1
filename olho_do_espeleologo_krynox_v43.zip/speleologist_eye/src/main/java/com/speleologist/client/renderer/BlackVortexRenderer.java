package com.speleologist.client.renderer;

import com.speleologist.item.BlackVortexItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class BlackVortexRenderer extends GeoItemRenderer<BlackVortexItem> {
	public BlackVortexRenderer() {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(BlackVortexItem a) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "geo/item/black_vortex.geo.json");
			}
			@Override
			public ResourceLocation getTextureResource(BlackVortexItem a) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "textures/item/black_vortex.png");
			}
			@Override
			public ResourceLocation getAnimationResource(BlackVortexItem a) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "animations/item/black_vortex.animation.json");
			}
		});
	}
}
