package com.speleologist.client;

import com.speleologist.client.screen.AdvancedCraftingScreen;
import com.speleologist.item.CyberScannerItem;
import com.speleologist.item.SpeleologistEyeItem;
import com.speleologist.screen.ModMenuTypes;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import com.speleologist.block.ModBlockEntities;
import com.speleologist.client.renderer.AdvancedCraftingTableRenderer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

public class SpeleologistClient implements ClientModInitializer {
	private static long activeUntil = 0;
	private static boolean scannerMode = false;
	/** Block where the effect was activated — player must stay near this. */
	private static BlockPos activationOrigin = null;
	/** Which item type is required in inventory while effect runs. */
	private static boolean requireScannerItem = false;
	private static boolean swingHandled = false; // only one activation per swing
	private static final Set<BlockPos> foundOres = new HashSet<>();
	private static final Set<BlockPos> foundChests = new HashSet<>();
	private static int scanCooldown = 0;
	private static int actionbarCooldown = 0;

	private static final float[] WHITE = {1f, 1f, 1f, 0.95f};
	private static final float[] DIAMOND = {0.3f, 0.9f, 1f, 0.95f};
	private static final float[] IRON = {0.85f, 0.85f, 0.9f, 0.9f};
	private static final float[] GOLD = {1f, 0.85f, 0.2f, 0.95f};
	private static final float[] REDSTONE = {1f, 0.2f, 0.2f, 0.95f};
	private static final float[] EMERALD = {0.2f, 1f, 0.4f, 0.95f};
	private static final float[] LAPIS = {0.3f, 0.4f, 1f, 0.95f};
	private static final float[] COAL = {0.3f, 0.3f, 0.3f, 0.9f};
	private static final float[] COPPER = {1f, 0.55f, 0.3f, 0.95f};
	private static final float[] ANCIENT = {0.6f, 0.3f, 0.2f, 0.95f};
	private static final float[] PHOTON = {0.3f, 1f, 1f, 1f};
	private static final float[] CHEST = {1f, 0.8f, 0.15f, 0.95f};

	@Override
	public void onInitializeClient() {
		BlockEntityRenderers.register(ModBlockEntities.ADVANCED_CRAFTING_TABLE, AdvancedCraftingTableRenderer::new);
		MenuScreens.register(ModMenuTypes.ADVANCED_CRAFTING, AdvancedCraftingScreen::new);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.player == null || client.level == null) return;
			Player player = client.player;

			ItemStack main = player.getMainHandItem();
			ItemStack off = player.getOffhandItem();
			boolean holdingEye = main.getItem() instanceof SpeleologistEyeItem || off.getItem() instanceof SpeleologistEyeItem;
			boolean holdingScanner = main.getItem() instanceof CyberScannerItem || off.getItem() instanceof CyberScannerItem;

			// Activation ONLY on a new swing (actual click/use), never by just holding
			if (player.swinging) {
				if (!swingHandled) {
					swingHandled = true;

					if (holdingEye) {
						var eyeItem = main.getItem() instanceof SpeleologistEyeItem ? main.getItem() : off.getItem();
						if (!player.getCooldowns().isOnCooldown(eyeItem)) {
							scannerMode = false;
							requireScannerItem = false;
							activeUntil = client.level.getGameTime() + 10 * 20L;
							activationOrigin = player.blockPosition().immutable();
							foundOres.clear();
							foundChests.clear();
							scanNearby(player);
						}
					}

					if (holdingScanner) {
						if (hasRedstone(player)) {
							scannerMode = true;
							requireScannerItem = true;
							activeUntil = client.level.getGameTime() + 3 * 60 * 20L;
							activationOrigin = player.blockPosition().immutable();
							foundOres.clear();
							foundChests.clear();
							scanNearby(player);
						}
					}
				}
			} else {
				swingHandled = false;
			}

			// Cancel effect: death, item removed from inventory, or left activation area
			if (client.level.getGameTime() < activeUntil) {
				boolean dead = player.isDeadOrDying() || player.getHealth() <= 0;
				boolean hasItem = requireScannerItem ? hasInInventory(player, true) : hasInInventory(player, false);
				boolean leftArea = activationOrigin != null && !isNearOrigin(player, activationOrigin, scannerMode ? 40 : 12);
				if (dead || !hasItem || leftArea) {
					clearEffect();
				}
			}

			// Effect only runs while timer is active
			if (client.level.getGameTime() < activeUntil) {
				actionbarCooldown--;
				if (actionbarCooldown <= 0) {
					long ticksLeft = activeUntil - client.level.getGameTime();
					int sec = (int) (ticksLeft / 20);
					String mode = scannerMode ? "§bScanner" : "§aEye";
					player.displayClientMessage(Component.literal(String.format("%s §f%02d:%02d", mode, sec / 60, sec % 60)), true);
					actionbarCooldown = 20;
				}

				// Light prune only — never full rescan (that was causing lag)
				scanCooldown--;
				if (scanCooldown <= 0) {
					pruneBroken(player);
					scanCooldown = 40; // every 2s
				}
			} else {
				foundOres.clear();
				foundChests.clear();
			}
		});

		WorldRenderEvents.AFTER_TRANSLUCENT.register(SpeleologistClient::renderOutlines);
	}

	private static boolean hasRedstone(Player player) {
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack s = player.getInventory().getItem(i);
			if (s.is(Items.REDSTONE) && s.getCount() > 0) return true;
		}
		return false;
	}


	private static void clearEffect() {
		activeUntil = 0;
		activationOrigin = null;
		foundOres.clear();
		foundChests.clear();
		scannerMode = false;
	}

	private static boolean hasInInventory(Player player, boolean scanner) {
		for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
			ItemStack stack = player.getInventory().getItem(i);
			if (scanner) {
				if (stack.getItem() instanceof CyberScannerItem) return true;
			} else {
				if (stack.getItem() instanceof SpeleologistEyeItem) return true;
			}
		}
		return false;
	}

	private static boolean isNearOrigin(Player player, BlockPos origin, int range) {
		BlockPos p = player.blockPosition();
		int dx = p.getX() - origin.getX();
		int dy = p.getY() - origin.getY();
		int dz = p.getZ() - origin.getZ();
		int rangeY = scannerMode ? 30 : range; // scanner: 30 up/down; eye: same as horizontal
		return dx * dx + dz * dz <= range * range && Math.abs(dy) <= rangeY;
	}

	private static void scanNearby(Player player) {
		// Scanner: radius 24 horizontal / 16 vertical — much cheaper than 40³
		// Eye: radius 8 / 8
		int range = scannerMode ? 40 : 12;
		int rangeY = scannerMode ? 30 : 12;
		BlockPos origin = activationOrigin != null ? activationOrigin : player.blockPosition();
		var level = player.level();
		for (int x = -range; x <= range; x++) {
			for (int z = -range; z <= range; z++) {
				if (x * x + z * z > range * range) continue;
				for (int y = -rangeY; y <= rangeY; y++) {
					BlockPos pos = origin.offset(x, y, z);
					BlockState state = level.getBlockState(pos);
					if (state.isAir()) continue;
					if (isOre(state)) {
						foundOres.add(pos.immutable());
						if (foundOres.size() > 400) return; // hard cap
					}
					if (scannerMode && isChest(state)) {
						foundChests.add(pos.immutable());
						if (foundChests.size() > 80) continue;
					}
				}
			}
		}
	}

	/** Only remove broken blocks — no full volume rescan (performance). */
	private static void pruneBroken(Player player) {
		foundOres.removeIf(pos -> !isOre(player.level().getBlockState(pos)));
		if (scannerMode) {
			foundChests.removeIf(pos -> !isChest(player.level().getBlockState(pos)));
		}
	}

	private static void updateScan(Player player) {
		pruneBroken(player);
	}

	private static void renderOutlines(WorldRenderContext context) {
		if (foundOres.isEmpty() && foundChests.isEmpty()) return;
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || mc.level == null) return;
		if (mc.level.getGameTime() >= activeUntil) return;

		Vec3 cam = context.camera().getPosition();
		Matrix4f matrix = context.matrixStack().last().pose();

		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableDepthTest();
		RenderSystem.setShader(GameRenderer::getPositionColorShader);
		RenderSystem.lineWidth(2.5f);

		Tesselator tesselator = Tesselator.getInstance();
		BufferBuilder buffer = tesselator.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);

		int drawn = 0;
		for (BlockPos pos : foundOres) {
			if (drawn++ > 250) break; // cap outlines to avoid GPU lag
			float[] c = getColor(mc.level.getBlockState(pos));
			drawBox(buffer, matrix, pos, cam, c[0], c[1], c[2], c[3]);
		}
		if (scannerMode) {
			for (BlockPos pos : foundChests) {
				drawBox(buffer, matrix, pos, cam, CHEST[0], CHEST[1], CHEST[2], CHEST[3]);
			}
		}

		BufferUploader.drawWithShader(buffer.buildOrThrow());
		RenderSystem.enableDepthTest();
		RenderSystem.disableBlend();
		RenderSystem.lineWidth(1.0f);
	}

	private static void drawBox(BufferBuilder buffer, Matrix4f matrix, BlockPos pos, Vec3 cam,
								float r, float g, float b, float a) {
		float x1 = (float) (pos.getX() - cam.x);
		float y1 = (float) (pos.getY() - cam.y);
		float z1 = (float) (pos.getZ() - cam.z);
		float x2 = x1 + 1, y2 = y1 + 1, z2 = z1 + 1;
		line(buffer, matrix, x1, y1, z1, x2, y1, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z1, x2, y1, z2, r, g, b, a);
		line(buffer, matrix, x2, y1, z2, x1, y1, z2, r, g, b, a);
		line(buffer, matrix, x1, y1, z2, x1, y1, z1, r, g, b, a);
		line(buffer, matrix, x1, y2, z1, x2, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y2, z1, x2, y2, z2, r, g, b, a);
		line(buffer, matrix, x2, y2, z2, x1, y2, z2, r, g, b, a);
		line(buffer, matrix, x1, y2, z2, x1, y2, z1, r, g, b, a);
		line(buffer, matrix, x1, y1, z1, x1, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z1, x2, y2, z1, r, g, b, a);
		line(buffer, matrix, x2, y1, z2, x2, y2, z2, r, g, b, a);
		line(buffer, matrix, x1, y1, z2, x1, y2, z2, r, g, b, a);
	}

	private static void line(BufferBuilder b, Matrix4f m, float x1, float y1, float z1, float x2, float y2, float z2, float r, float g, float bl, float a) {
		b.addVertex(m, x1, y1, z1).setColor(r, g, bl, a);
		b.addVertex(m, x2, y2, z2).setColor(r, g, bl, a);
	}

	private static float[] getColor(BlockState state) {
		if (state.getBlock() == com.speleologist.block.ModBlocks.PHOTON_ORE) return PHOTON;
		if (state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE)) return DIAMOND;
		if (state.is(Blocks.IRON_ORE) || state.is(Blocks.DEEPSLATE_IRON_ORE)) return IRON;
		if (state.is(Blocks.GOLD_ORE) || state.is(Blocks.DEEPSLATE_GOLD_ORE) || state.is(Blocks.NETHER_GOLD_ORE)) return GOLD;
		if (state.is(Blocks.REDSTONE_ORE) || state.is(Blocks.DEEPSLATE_REDSTONE_ORE)) return REDSTONE;
		if (state.is(Blocks.EMERALD_ORE) || state.is(Blocks.DEEPSLATE_EMERALD_ORE)) return EMERALD;
		if (state.is(Blocks.LAPIS_ORE) || state.is(Blocks.DEEPSLATE_LAPIS_ORE)) return LAPIS;
		if (state.is(Blocks.COAL_ORE) || state.is(Blocks.DEEPSLATE_COAL_ORE)) return COAL;
		if (state.is(Blocks.COPPER_ORE) || state.is(Blocks.DEEPSLATE_COPPER_ORE)) return COPPER;
		if (state.is(Blocks.ANCIENT_DEBRIS)) return ANCIENT;
		return WHITE;
	}

	private static boolean isOre(BlockState state) {
		if (state.is(Blocks.COAL_ORE) || state.is(Blocks.DEEPSLATE_COAL_ORE) ||
			state.is(Blocks.IRON_ORE) || state.is(Blocks.DEEPSLATE_IRON_ORE) ||
			state.is(Blocks.COPPER_ORE) || state.is(Blocks.DEEPSLATE_COPPER_ORE) ||
			state.is(Blocks.GOLD_ORE) || state.is(Blocks.DEEPSLATE_GOLD_ORE) ||
			state.is(Blocks.REDSTONE_ORE) || state.is(Blocks.DEEPSLATE_REDSTONE_ORE) ||
			state.is(Blocks.EMERALD_ORE) || state.is(Blocks.DEEPSLATE_EMERALD_ORE) ||
			state.is(Blocks.LAPIS_ORE) || state.is(Blocks.DEEPSLATE_LAPIS_ORE) ||
			state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE) ||
			state.is(Blocks.NETHER_GOLD_ORE) || state.is(Blocks.NETHER_QUARTZ_ORE) ||
			state.is(Blocks.ANCIENT_DEBRIS) || state.is(Blocks.GILDED_BLACKSTONE)) return true;
		return state.getBlock() == com.speleologist.block.ModBlocks.PHOTON_ORE;
	}

	private static boolean isChest(BlockState state) {
		return state.is(Blocks.CHEST) || state.is(Blocks.TRAPPED_CHEST) ||
			   state.is(Blocks.BARREL) || state.is(Blocks.ENDER_CHEST) || state.is(BlockTags.SHULKER_BOXES);
	}
}
