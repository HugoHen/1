package com.speleologist.client.screen;

import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/** 7x7 crafting GUI using the custom texture. */
public class AdvancedCraftingScreen extends AbstractContainerScreen<AdvancedCraftingMenu> {
	private static final ResourceLocation TEXTURE =
			ResourceLocation.fromNamespaceAndPath("antenden", "textures/gui/advanced_crafting.png");

	public AdvancedCraftingScreen(AdvancedCraftingMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		this.imageWidth = 176;
		this.imageHeight = 240;
		this.titleLabelX = 8;
		this.titleLabelY = 6;
		this.inventoryLabelX = 8;
		this.inventoryLabelY = 144;
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float delta, int mouseX, int mouseY) {
		int x = this.leftPos;
		int y = this.topPos;
		// Draw full GUI texture stretched to image size
		graphics.blit(TEXTURE, x, y, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		renderBackground(graphics, mouseX, mouseY, delta);
		super.render(graphics, mouseX, mouseY, delta);
		renderTooltip(graphics, mouseX, mouseY);
	}

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		// Labels are already in the texture (Inventory)
		graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x404040, false);
	}
}
