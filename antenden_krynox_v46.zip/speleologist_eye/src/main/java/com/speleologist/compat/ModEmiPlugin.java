package com.speleologist.compat;

import com.speleologist.SpeleologistMod;
import com.speleologist.item.ModItems;
import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipe;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.WidgetHolder;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** EMI recipes for the 7x7 Advanced Crafting Table. */
public class ModEmiPlugin implements EmiPlugin {
	public static final ResourceLocation ID = SpeleologistMod.id("advanced_7x7");
	public static final EmiStack WORKSTATION = EmiStack.of(ModItems.ADVANCED_CRAFTING_TABLE);
	public static final EmiRecipeCategory CATEGORY = new EmiRecipeCategory(ID, WORKSTATION);
	private static final int GRID = 7;
	private static final int SIZE = 49;
	private static final int CENTER = 24;

	@Override
	public void register(EmiRegistry registry) {
		registry.addCategory(CATEGORY);
		registry.addWorkstation(CATEGORY, WORKSTATION);

		fill(registry, "compacted_redstone", EmiStack.of(Items.REDSTONE_BLOCK), EmiStack.of(ModItems.COMPACTED_REDSTONE));
		fill(registry, "redstone_2x", EmiStack.of(ModItems.COMPACTED_REDSTONE), EmiStack.of(ModItems.REDSTONE_2X));
		fill(registry, "redstone_3x", EmiStack.of(ModItems.REDSTONE_2X), EmiStack.of(ModItems.REDSTONE_3X));
		fill(registry, "redstone_complete", EmiStack.of(ModItems.REDSTONE_3X), EmiStack.of(ModItems.REDSTONE_COMPLETE));
		fill(registry, "compacted_iron", EmiStack.of(Items.IRON_BLOCK), EmiStack.of(ModItems.COMPACTED_IRON));
		fill(registry, "iron_2x", EmiStack.of(ModItems.COMPACTED_IRON), EmiStack.of(ModItems.IRON_2X));
		fill(registry, "iron_3x", EmiStack.of(ModItems.IRON_2X), EmiStack.of(ModItems.IRON_3X));
		fill(registry, "iron_complete", EmiStack.of(ModItems.IRON_3X), EmiStack.of(ModItems.IRON_COMPLETE));
		fill(registry, "photon_semi", EmiStack.of(ModItems.PHOTON_FRAGMENT), EmiStack.of(ModItems.PHOTON_SEMI));
		fill(registry, "photon_complete", EmiStack.of(ModItems.PHOTON_SEMI), EmiStack.of(ModItems.PHOTON_COMPLETE));

		List<EmiIngredient> rf = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.of(ModItems.REDSTONE_COMPLETE)));
		rf.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/redstone_flow"), rf, EmiStack.of(ModItems.REDSTONE_FLOW, 2)));

		List<EmiIngredient> irf = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.of(ModItems.IRON_COMPLETE)));
		irf.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/iron_flow"), irf, EmiStack.of(ModItems.IRON_FLOW, 2)));

		// First flow: center ender eye, 8 diamond, 8 RF, 8 IF (simplified layout for EMI)
		List<EmiIngredient> first = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.EMPTY));
		first.set(CENTER, EmiStack.of(Items.ENDER_EYE));
		int[] diamonds = {10, 12, 16, 22, 26, 32, 36, 38};
		for (int i : diamonds) first.set(i, EmiStack.of(Items.DIAMOND_BLOCK));
		int[] rfs = {0, 2, 4, 6, 42, 44, 46, 48};
		for (int i : rfs) first.set(i, EmiStack.of(ModItems.REDSTONE_FLOW));
		int[] ifs = {14, 18, 20, 24, 28, 30, 34, 40};
		// avoid overwriting center
		int[] ifs2 = {14, 18, 20, 28, 30, 34, 40, 8};
		for (int i : ifs2) if (i != CENTER) first.set(i, EmiStack.of(ModItems.IRON_FLOW));
		registry.addRecipe(new R(SpeleologistMod.id("emi/first_flow"), first, EmiStack.of(ModItems.FIRST_FLOW)));

		// Black vortex: 4 photon + 1 eye
		List<EmiIngredient> bv = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.EMPTY));
		bv.set(CENTER, EmiStack.of(ModItems.SPELEOLOGIST_EYE));
		bv.set(CENTER - 7, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER + 7, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER - 1, EmiStack.of(ModItems.PHOTON_COMPLETE));
		bv.set(CENTER + 1, EmiStack.of(ModItems.PHOTON_COMPLETE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/black_vortex"), bv, EmiStack.of(ModItems.BLACK_VORTEX)));

		// Scanner count recipe shown as sparse grid
		List<EmiIngredient> sc = new ArrayList<>(Collections.nCopies(SIZE, EmiStack.EMPTY));
		sc.set(CENTER, EmiStack.of(ModItems.BLACK_VORTEX));
		sc.set(0, EmiStack.of(Items.ENDER_EYE));
		sc.set(6, EmiStack.of(Items.ENDER_EYE));
		sc.set(42, EmiStack.of(Items.ENDER_EYE));
		sc.set(48, EmiStack.of(Items.ENDER_EYE));
		sc.set(3, EmiStack.of(ModItems.COMPACTED_IRON));
		sc.set(45, EmiStack.of(ModItems.COMPACTED_IRON));
		sc.set(21, EmiStack.of(ModItems.COMPACTED_REDSTONE));
		sc.set(27, EmiStack.of(ModItems.COMPACTED_REDSTONE));
		registry.addRecipe(new R(SpeleologistMod.id("emi/cyber_scanner"), sc, EmiStack.of(ModItems.CYBER_SCANNER)));
	}

	private void fill(EmiRegistry registry, String id, EmiStack input, EmiStack output) {
		List<EmiIngredient> inputs = new ArrayList<>(Collections.nCopies(SIZE, input));
		registry.addRecipe(new R(SpeleologistMod.id("emi/" + id), inputs, output));
	}

	static class R implements EmiRecipe {
		private final ResourceLocation id;
		private final List<EmiIngredient> inputs;
		private final EmiStack output;

		R(ResourceLocation id, List<EmiIngredient> inputs, EmiStack output) {
			this.id = id;
			this.inputs = inputs;
			this.output = output;
		}

		@Override public EmiRecipeCategory getCategory() { return CATEGORY; }
		@Override public ResourceLocation getId() { return id; }
		@Override public List<EmiIngredient> getInputs() { return inputs; }
		@Override public List<EmiStack> getOutputs() { return List.of(output); }
		@Override public int getDisplayWidth() { return 150; }
		@Override public int getDisplayHeight() { return 140; }

		@Override
		public void addWidgets(WidgetHolder widgets) {
			for (int i = 0; i < SIZE; i++) {
				int row = i / GRID;
				int col = i % GRID;
				widgets.addSlot(inputs.get(i), col * 18, row * 18);
			}
			widgets.addSlot(output, 132, 54).recipeContext(this);
		}
	}
}
