package com.speleologist.client.renderer;

import com.speleologist.item.AdvancedCraftingTableItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class AdvancedCraftingTableItemRenderer extends GeoItemRenderer<AdvancedCraftingTableItem> {
	public AdvancedCraftingTableItemRenderer() {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(AdvancedCraftingTableItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "geo/item/advanced_crafting_table.geo.json");
			}

			@Override
			public ResourceLocation getTextureResource(AdvancedCraftingTableItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "textures/block/advanced_crafting_table.png");
			}

			@Override
			public ResourceLocation getAnimationResource(AdvancedCraftingTableItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "animations/block/advanced_crafting_table.animation.json");
			}
		});
	}
}
