package com.speleologist.client.renderer;

import com.speleologist.item.CyberArmorItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class CyberArmorItemRenderer extends GeoItemRenderer<CyberArmorItem> {
	public CyberArmorItemRenderer() {
		super(new GeoModel<>() {
			private String piece(CyberArmorItem item) {
				return switch (item.getType()) {
					case HELMET -> "cyber_helmet";
					case CHESTPLATE -> "cyber_chestplate";
					case LEGGINGS -> "cyber_leggings";
					case BOOTS -> "cyber_boots";
					default -> "cyber_chestplate";
				};
			}

			@Override
			public ResourceLocation getModelResource(CyberArmorItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "geo/armor/" + piece(animatable) + ".geo.json");
			}

			@Override
			public ResourceLocation getTextureResource(CyberArmorItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "textures/armor/" + piece(animatable) + ".png");
			}

			@Override
			public ResourceLocation getAnimationResource(CyberArmorItem animatable) {
				return ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "animations/armor/cyber_armor.animation.json");
			}
		});
	}
}
