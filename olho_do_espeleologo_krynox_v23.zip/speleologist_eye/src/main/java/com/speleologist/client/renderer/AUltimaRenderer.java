package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.speleologist.item.AUltimaItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/**
 * Scale 1.0 = same size as the exported geo.json (user's 3D file).
 * Model is ~69 units tall ≈ 4+ blocks — intentional full-size display.
 */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}

	@Override
	public void renderByItem(net.minecraft.world.item.ItemStack stack, ItemDisplayContext transformType,
			PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		poseStack.pushPose();
		// 1:1 with the geo file — no downscale
		if (transformType == ItemDisplayContext.GUI) {
			// GUI only: shrink so it fits the inventory slot
			poseStack.scale(0.15f, 0.15f, 0.15f);
			poseStack.translate(0.0, -0.2, 0.0);
		} else if (transformType == ItemDisplayContext.FIXED) {
			// item frame: still readable
			poseStack.scale(0.25f, 0.25f, 0.25f);
		} else if (transformType == ItemDisplayContext.GROUND) {
			poseStack.scale(1.0f, 1.0f, 1.0f);
			poseStack.translate(0.0, 0.0, 0.0);
		} else {
			// first person + third person = full file size
			poseStack.scale(1.0f, 1.0f, 1.0f);
		}
		super.renderByItem(stack, transformType, poseStack, bufferSource, packedLight, packedOverlay);
		poseStack.popPose();
	}
}
