package com.speleologist.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.speleologist.item.AUltimaItem;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

/**
 * Model origin is at the bottom of the shaft.
 * Grip (brown between gold rings) is ~12 units up the handle in geo space.
 * We translate so that grip point sits in the player's hand.
 */
public class AUltimaRenderer extends GeoItemRenderer<AUltimaItem> {
	/** Geo Y of the brown grip between the gold bands */
	private static final float GRIP_Y = 12.0f;
	/** Convert geo units to block units (1 block = 16 geo units) */
	private static final float GEO_TO_BLOCK = 1.0f / 16.0f;

	public AUltimaRenderer() {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", "a_ultima")));
	}

	@Override
	public void renderByItem(net.minecraft.world.item.ItemStack stack, ItemDisplayContext transformType,
			PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
		poseStack.pushPose();

		// Shift model down so GRIP_Y lands near the hand attachment point
		float gripOffset = -GRIP_Y * GEO_TO_BLOCK;

		switch (transformType) {
			case FIRST_PERSON_RIGHT_HAND, FIRST_PERSON_LEFT_HAND -> {
				poseStack.translate(0.0, gripOffset + 0.15, 0.0);
			}
			case THIRD_PERSON_RIGHT_HAND, THIRD_PERSON_LEFT_HAND -> {
				poseStack.translate(0.0, gripOffset + 0.35, 0.05);
			}
			case GROUND -> {
				// Bigger on ground + rest on surface
				poseStack.translate(0.0, 0.15, 0.0);
				poseStack.scale(1.35f, 1.35f, 1.35f);
			}
			case FIXED -> {
				// Item frame: center the whole pickaxe in the frame
				poseStack.translate(0.0, gripOffset * 0.5f - 0.2, -0.05);
				poseStack.mulPose(Axis.ZP.rotationDegrees(-45));
			}
			case GUI -> {
				poseStack.translate(0.0, gripOffset * 0.3f, 0.0);
			}
			default -> {
			}
		}

		super.renderByItem(stack, transformType, poseStack, bufferSource, packedLight, packedOverlay);
		poseStack.popPose();
	}
}
