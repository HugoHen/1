package com.speleologist.screen;

import com.speleologist.item.ModItems;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class AdvancedCraftingMenu extends AbstractContainerMenu {
	public static final int GRID = 7;
	public static final int GRID_SIZE = 49;
	public static final int CENTER = 24;

	private final CraftingContainer craftSlots;
	private final ResultContainer resultSlots = new ResultContainer();
	private final ContainerLevelAccess access;
	private final Level level;

	public AdvancedCraftingMenu(int syncId, Inventory playerInv) {
		this(syncId, playerInv, ContainerLevelAccess.NULL);
	}

	public AdvancedCraftingMenu(int syncId, Inventory playerInv, ContainerLevelAccess access) {
		super(ModMenuTypes.ADVANCED_CRAFTING, syncId);
		this.access = access;
		this.level = playerInv.player.level();
		this.craftSlots = new CraftingContainer(this, GRID_SIZE);

		for (int row = 0; row < GRID; row++) {
			for (int col = 0; col < GRID; col++) {
				this.addSlot(new Slot(craftSlots, col + row * GRID, 7 + col * 18, 17 + row * 18));
			}
		}
		this.addSlot(new ResultSlot(resultSlots, 0, 151, 71));

		int invY = 156;
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInv, col + row * 9 + 9, 7 + col * 18, invY - 1 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInv, col, 7 + col * 18, invY + 57));
		}
	}

	private class ResultSlot extends Slot {
		public ResultSlot(Container c, int i, int x, int y) { super(c, i, x, y); }
		@Override public boolean mayPlace(ItemStack s) { return false; }
		@Override public boolean mayPickup(Player p) { return hasItem(); }
		@Override
		public void onTake(Player player, ItemStack stack) {
			consumeIngredientsOnce();
			updateResult();
			super.onTake(player, stack);
		}
		@Override
		public ItemStack remove(int amount) {
			ItemStack cur = getItem();
			if (cur.isEmpty()) return ItemStack.EMPTY;
			ItemStack t = cur.copy();
			set(ItemStack.EMPTY);
			return t;
		}
	}

	private void consumeIngredientsOnce() {
		craftSlots.silent = true;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) {
				s.shrink(1);
				if (s.isEmpty()) craftSlots.items.set(i, ItemStack.EMPTY);
			}
		}
		craftSlots.silent = false;
	}

	private int maxCraftsPossible() {
		if (computeResult().isEmpty()) return 0;
		int max = 64;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) max = Math.min(max, s.getCount());
		}
		return Math.max(0, max);
	}

	@Override
	public void slotsChanged(Container container) {
		if (level == null || level.isClientSide) return;
		updateResult();
	}

	private void updateResult() {
		resultSlots.setItem(0, computeResult());
		broadcastChanges();
	}

	/** Pattern: 7 strings of length 7. Char maps to item; space = empty; '.' = any non-empty ignored as empty only match empty */
	private boolean matches(String[] pattern, java.util.Map<Character, Item> key) {
		if (pattern.length != 7) return false;
		for (int r = 0; r < 7; r++) {
			String row = pattern[r];
			if (row.length() != 7) return false;
			for (int c = 0; c < 7; c++) {
				char ch = row.charAt(c);
				ItemStack stack = craftSlots.getItem(r * 7 + c);
				if (ch == ' ') {
					if (!stack.isEmpty()) return false;
				} else {
					Item expected = key.get(ch);
					if (expected == null || !stack.is(expected)) return false;
				}
			}
		}
		return true;
	}

	private ItemStack computeResult() {
		// --- Compacted chains (full 7x7) ---
		int f = filled();
		if (f == 49 && count(Items.REDSTONE_BLOCK) == 49) return new ItemStack(ModItems.COMPACTED_REDSTONE);
		if (f == 49 && count(ModItems.COMPACTED_REDSTONE) == 49) return new ItemStack(ModItems.REDSTONE_2X);
		if (f == 49 && count(ModItems.REDSTONE_2X) == 49) return new ItemStack(ModItems.REDSTONE_3X);
		if (f == 49 && count(ModItems.REDSTONE_3X) == 49) return new ItemStack(ModItems.REDSTONE_COMPLETE);
		if (f == 49 && count(Items.IRON_BLOCK) == 49) return new ItemStack(ModItems.COMPACTED_IRON);
		if (f == 49 && count(ModItems.COMPACTED_IRON) == 49) return new ItemStack(ModItems.IRON_2X);
		if (f == 49 && count(ModItems.IRON_2X) == 49) return new ItemStack(ModItems.IRON_3X);
		if (f == 49 && count(ModItems.IRON_3X) == 49) return new ItemStack(ModItems.IRON_COMPLETE);
		if (f == 49 && count(ModItems.REDSTONE_COMPLETE) == 48 && craftSlots.getItem(CENTER).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.REDSTONE_FLOW, 2);
		if (f == 49 && count(ModItems.IRON_COMPLETE) == 48 && craftSlots.getItem(CENTER).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.IRON_FLOW, 2);

		// Photon Semi — fragments in pattern
		if (matches(PHOTON_SEMI, java.util.Map.of('F', ModItems.PHOTON_FRAGMENT)))
			return new ItemStack(ModItems.PHOTON_SEMI);

		// Photon Complete — photon semi in pattern
		if (matches(PHOTON_COMPLETE, java.util.Map.of('F', ModItems.PHOTON_SEMI)))
			return new ItemStack(ModItems.PHOTON_COMPLETE);

		// Star — nether stars
		if (matches(STAR_SHAPE, java.util.Map.of('N', Items.NETHER_STAR)))
			return new ItemStack(ModItems.STAR);

		// Big Star — stars
		if (matches(STAR_SHAPE, java.util.Map.of('N', ModItems.STAR)))
			return new ItemStack(ModItems.BIG_STAR);

		// The First Star — big stars
		if (matches(STAR_SHAPE, java.util.Map.of('N', ModItems.BIG_STAR)))
			return new ItemStack(ModItems.THE_FIRST_STAR);

		// Two-plate vortex
		if (matches(TWO_PLATE, java.util.Map.of(
				'E', Items.ENDER_EYE,
				'N', Items.NETHER_STAR,
				'D', Items.DIAMOND_BLOCK,
				'R', ModItems.REDSTONE_FLOW,
				'I', ModItems.IRON_FLOW
		))) return new ItemStack(ModItems.FIRST_FLOW);

		// Armor pieces
		var armorKey = java.util.Map.of(
				'C', ModItems.CARAMEL_VORTEX,
				'T', ModItems.FIRST_FLOW,
				'F', ModItems.THE_FIRST_STAR,
				'B', ModItems.BLACK_VORTEX,
				'E', ModItems.SPELEOLOGIST_EYE
		);
		if (matches(ARMOR_HELMET, armorKey)) return new ItemStack(ModItems.CYBER_HELMET);
		if (matches(ARMOR_CHEST, armorKey)) return new ItemStack(ModItems.CYBER_CHESTPLATE);
		if (matches(ARMOR_LEGS, armorKey)) return new ItemStack(ModItems.CYBER_LEGGINGS);
		if (matches(ARMOR_BOOTS, armorKey)) return new ItemStack(ModItems.CYBER_BOOTS);

		// Black vortex simple
		if (count(ModItems.SPELEOLOGIST_EYE) == 1 && count(ModItems.PHOTON_COMPLETE) == 4 && filled() == 5)
			return new ItemStack(ModItems.BLACK_VORTEX);

		// Scanner
		if (count(Items.ENDER_EYE) == 4 && count(ModItems.COMPACTED_IRON) == 2
				&& count(ModItems.COMPACTED_REDSTONE) == 2 && count(ModItems.BLACK_VORTEX) == 1 && filled() == 9)
			return new ItemStack(ModItems.CYBER_SCANNER);

		return ItemStack.EMPTY;
	}

	
	
	/* Patterns 7x7 — exact length 7 per row. Space = empty. */

	// Photon Semi: fragments in diamond-ish shape
	private static final String[] PHOTON_SEMI = {
			" FF  F ",
			"FFFFFF ",
			"FFFFFF ",
			"FFFFFF ",
			"FFFFFF ",
			" FFFF  ",
			"  FF   "
	};
	// Photon Complete: photon semi same shape
	private static final String[] PHOTON_COMPLETE = {
			"  FFF  ",
			" FFFFF ",
			"FFFFFF ",
			"FFFFFF ",
			" FFFFF ",
			"  FFF  ",
			"  FF   "
	};
	// Star / Big Star / The First Star chain
	private static final String[] STAR_SHAPE = {
			"  NNN  ",
			" NNNNN ",
			"NNNNNNN",
			"NNNNNNN",
			" NNNNN ",
			"  NNN  ",
			"   N   "
	};
	// Two-plate vortex: E=ender eye N=nether star D=diamond block R=redstone vortex I=iron vortex
	private static final String[] TWO_PLATE = {
			"  N N  ",
			" R D R ",
			"RDINIDR",
			"DN E ND",
			" RIDIR ",
			"  RDR  ",
			"   N   "
	};
	// Armor: C=caramel T=two-plate F=first star B=black E=olho da fehr
	private static final String[] ARMOR_HELMET = {
			" CC CC ",
			"C C CC ",
			"CF   FC",
			"CT C TC",
			"CF B FC",
			" CCCC  ",
			"  C C  "
	};
	private static final String[] ARMOR_CHEST = {
			" CC CC ",
			"CCCCCCC",
			"CT E TC",
			"CT F TC",
			"CB F BC",
			"  CBC  ",
			"  CCC  "
	};
	private static final String[] ARMOR_LEGS = {
			"  TCT  ",
			" TBC T ",
			"CBCBCBC",
			"CT C TC",
			" TFTFT ",
			" CTC C ",
			"  C C  "
	};
	private static final String[] ARMOR_BOOTS = {
			"       ",
			" TCTCT ",
			" CBBBC ",
			"  CBC  ",
			"  C C  ",
			" CCFCC ",
			" CFCFC "
	};

	private int count(Item item) {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) if (craftSlots.getItem(i).is(item)) n++;
		return n;
	}

	private int filled() {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) if (!craftSlots.getItem(i).isEmpty()) n++;
		return n;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;
		if (index == GRID_SIZE) {
			ItemStack assembled = ItemStack.EMPTY;
			int crafts = 0;
			int max = Math.min(maxCraftsPossible(), 64);
			while (crafts < max) {
				ItemStack result = computeResult();
				if (result.isEmpty()) break;
				ItemStack single = result.copy();
				if (!this.moveItemStackTo(single, GRID_SIZE + 1, this.slots.size(), true)) break;
				consumeIngredientsOnce();
				crafts++;
				assembled = result.copy();
			}
			updateResult();
			return assembled;
		}
		ItemStack original = slot.getItem();
		ItemStack copy = original.copy();
		if (index > GRID_SIZE) {
			if (!this.moveItemStackTo(original, 0, GRID_SIZE, false)) return ItemStack.EMPTY;
		} else {
			if (!this.moveItemStackTo(original, GRID_SIZE + 1, this.slots.size(), false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
		else slot.setChanged();
		updateResult();
		return copy;
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(this.access, player, com.speleologist.block.ModBlocks.ADVANCED_CRAFTING_TABLE);
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.access.execute((level, pos) -> this.clearContainer(player, this.craftSlots));
	}

	static class CraftingContainer implements Container {
		final NonNullList<ItemStack> items;
		final AdvancedCraftingMenu menu;
		boolean silent;
		CraftingContainer(AdvancedCraftingMenu menu, int size) {
			this.menu = menu;
			this.items = NonNullList.withSize(size, ItemStack.EMPTY);
		}
		@Override public int getContainerSize() { return items.size(); }
		@Override public boolean isEmpty() { return items.stream().allMatch(ItemStack::isEmpty); }
		@Override public ItemStack getItem(int i) { return items.get(i); }
		@Override public ItemStack removeItem(int i, int c) {
			ItemStack r = ContainerHelper.removeItem(items, i, c);
			if (!r.isEmpty() && !silent) menu.slotsChanged(this);
			return r;
		}
		@Override public ItemStack removeItemNoUpdate(int i) { return ContainerHelper.takeItem(items, i); }
		@Override public void setItem(int i, ItemStack stack) {
			items.set(i, stack);
			if (!silent) menu.slotsChanged(this);
		}
		@Override public void setChanged() {}
		@Override public boolean stillValid(Player player) { return true; }
		@Override public void clearContent() { items.clear(); }
	}
}
