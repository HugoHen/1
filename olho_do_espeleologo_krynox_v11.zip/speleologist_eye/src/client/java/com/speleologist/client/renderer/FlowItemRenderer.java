package com.speleologist.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

@SuppressWarnings({"rawtypes", "unchecked"})
public class FlowItemRenderer extends GeoItemRenderer {
	public FlowItemRenderer(String name) {
		super(new DefaultedItemGeoModel<>(ResourceLocation.fromNamespaceAndPath("olho_do_espeleologo", name)));
	}
}
