package com.speleologist.client.screen;

import com.speleologist.screen.AdvancedCraftingMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

public class AdvancedCraftingScreen extends AbstractContainerScreen<AdvancedCraftingMenu> {

	public AdvancedCraftingScreen(AdvancedCraftingMenu menu, Inventory inv, Component title) {
		super(menu, inv, title);
		this.imageWidth = 176;
		this.imageHeight = 202;
		this.inventoryLabelY = 108;
		this.titleLabelY = 6;
	}

	@Override
	protected void renderBg(GuiGraphics graphics, float delta, int mouseX, int mouseY) {
		int x = (width - imageWidth) / 2;
		int y = (height - imageHeight) / 2;

		// Outer cyber frame - dark blue/cyan
		graphics.fill(x - 2, y - 2, x + imageWidth + 2, y + imageHeight + 2, 0xFF00E5FF);
		graphics.fill(x, y, x + imageWidth, y + imageHeight, 0xFF0A0E1A);

		// Inner panel
		graphics.fill(x + 3, y + 3, x + imageWidth - 3, y + imageHeight - 3, 0xFF12182B);

		// Title bar cyber
		graphics.fill(x + 3, y + 3, x + imageWidth - 3, y + 16, 0xFF1A2744);
		// cyan accent line under title
		graphics.fill(x + 3, y + 16, x + imageWidth - 3, y + 17, 0xFF00BCD4);

		// 5x5 grid slots - cyber style
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				int sx = x + 11 + col * 18;
				int sy = y + 16 + row * 18;
				// slot border cyan
				graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF00ACC1);
				graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D1526);
			}
		}

		// Arrow area
		graphics.fill(x + 112, y + 54, x + 140, y + 68, 0xFF1A2744);
		// Result slot
		graphics.fill(x + 146, y + 52, x + 164, y + 70, 0xFF00E5FF);
		graphics.fill(x + 147, y + 53, x + 163, y + 69, 0xFF0D1526);

		// Player inventory area label line
		graphics.fill(x + 3, y + 114, x + imageWidth - 3, y + 115, 0xFF00BCD4);

		// Player inventory slots
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				int sx = x + 7 + col * 18;
				int sy = y + 119 + row * 18;
				graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF263238);
				graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D1526);
			}
		}
		// Hotbar
		for (int col = 0; col < 9; col++) {
			int sx = x + 7 + col * 18;
			int sy = y + 177;
			graphics.fill(sx, sy, sx + 18, sy + 18, 0xFF263238);
			graphics.fill(sx + 1, sy + 1, sx + 17, sy + 17, 0xFF0D1526);
		}

		// Corner accents
		graphics.fill(x, y, x + 8, y + 2, 0xFF00E5FF);
		graphics.fill(x, y, x + 2, y + 8, 0xFF00E5FF);
		graphics.fill(x + imageWidth - 8, y, x + imageWidth, y + 2, 0xFF00E5FF);
		graphics.fill(x + imageWidth - 2, y, x + imageWidth, y + 8, 0xFF00E5FF);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		renderBackground(graphics, mouseX, mouseY, delta);
		super.render(graphics, mouseX, mouseY, delta);
		renderTooltip(graphics, mouseX, mouseY);
	}

	@Override
	protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
		graphics.drawString(this.font, this.title, this.titleLabelX, this.titleLabelY, 0x00E5FF, false);
		graphics.drawString(this.font, this.playerInventoryTitle, this.inventoryLabelX, this.inventoryLabelY, 0x80CBC4, false);
	}
}
