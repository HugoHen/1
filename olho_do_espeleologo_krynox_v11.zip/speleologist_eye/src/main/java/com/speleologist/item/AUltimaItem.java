package com.speleologist.item;

import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.Unbreakable;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;
import java.util.function.Consumer;

public class AUltimaItem extends Item implements GeoItem {
	public static final String DAMAGE_TAG = "UltimaDamage";
	public static final float BASE_DAMAGE = 50f;
	public static final float MAX_DAMAGE = 1_000_000f;
	private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

	public AUltimaItem() {
		super(new Item.Properties()
				.stacksTo(1)
				.rarity(Rarity.EPIC)
				.fireResistant()
				.attributes(createAttributes(BASE_DAMAGE))
				.component(DataComponents.UNBREAKABLE, new Unbreakable(true))
		);
	}

	@Override
	public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
		consumer.accept(new GeoRenderProvider() {
			private com.speleologist.client.renderer.AUltimaRenderer renderer;
			@Override
			public BlockEntityWithoutLevelRenderer getGeoItemRenderer() {
				if (renderer == null) renderer = new com.speleologist.client.renderer.AUltimaRenderer();
				return renderer;
			}
		});
	}

	@Override
	public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
		controllers.add(new AnimationController<>(this, "controller", 0, state -> {
			state.setAnimation(RawAnimation.begin().thenLoop("idle"));
			return PlayState.CONTINUE;
		}));
	}

	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {
		return cache;
	}

	public static ItemAttributeModifiers createAttributes(float attackDamage) {
		return ItemAttributeModifiers.builder()
				.add(Attributes.ATTACK_DAMAGE,
						new AttributeModifier(BASE_ATTACK_DAMAGE_ID, attackDamage, AttributeModifier.Operation.ADD_VALUE),
						EquipmentSlotGroup.MAINHAND)
				.add(Attributes.ATTACK_SPEED,
						new AttributeModifier(BASE_ATTACK_SPEED_ID, -2.4, AttributeModifier.Operation.ADD_VALUE),
						EquipmentSlotGroup.MAINHAND)
				.build();
	}

	public static float getDamageLevel(ItemStack stack) {
		try {
			var custom = stack.get(DataComponents.CUSTOM_DATA);
			if (custom != null) {
				var tag = custom.copyTag();
				if (tag.contains(DAMAGE_TAG)) {
					return Math.min(MAX_DAMAGE, Math.max(BASE_DAMAGE, tag.getFloat(DAMAGE_TAG)));
				}
			}
		} catch (Exception ignored) {}
		return BASE_DAMAGE;
	}

	@Override
	public float getDestroySpeed(ItemStack stack, BlockState state) {
		return 45f;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack stack, BlockState state) {
		return true;
	}

	@Override
	public boolean mineBlock(ItemStack stack, Level level, BlockState state, BlockPos pos, LivingEntity entity) {
		return true;
	}

	@Override
	public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
		return true;
	}

	@Override
	public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
		float dmg = getDamageLevel(stack);
		tooltip.add(Component.literal("§5§o\"there is nothing I cannot break...\""));
		tooltip.add(Component.literal("§7Pickaxe + Axe"));
		tooltip.add(Component.literal("§7Efficiency 10 | Fortune 10 | Sharpness 10"));
		tooltip.add(Component.literal("§bUnbreakable"));
		tooltip.add(Component.literal("§7Breaks Bedrock"));
		tooltip.add(Component.literal(String.format("§cDamage: §f%.0f §8/ 1000000", dmg)));
		super.appendHoverText(stack, context, tooltip, flag);
	}
}
