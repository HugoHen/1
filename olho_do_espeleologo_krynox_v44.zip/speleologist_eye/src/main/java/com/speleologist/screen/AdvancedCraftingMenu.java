package com.speleologist.screen;

import com.speleologist.item.ModItems;
import net.minecraft.core.NonNullList;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class AdvancedCraftingMenu extends AbstractContainerMenu {
	public static final int GRID = 7;
	public static final int GRID_SIZE = 49; // 7x7
	public static final int CENTER = 24; // 3*7+3

	private final CraftingContainer craftSlots;
	private final ResultContainer resultSlots = new ResultContainer();
	private final ContainerLevelAccess access;
	private final Level level;
	private final Player player;

	public AdvancedCraftingMenu(int syncId, Inventory playerInv) {
		this(syncId, playerInv, ContainerLevelAccess.NULL);
	}

	public AdvancedCraftingMenu(int syncId, Inventory playerInv, ContainerLevelAccess access) {
		super(ModMenuTypes.ADVANCED_CRAFTING, syncId);
		this.access = access;
		this.level = playerInv.player.level();
		this.player = playerInv.player;
		this.craftSlots = new CraftingContainer(this, GRID_SIZE);

		// 7x7 grid starting at (8, 18)
		for (int row = 0; row < GRID; row++) {
			for (int col = 0; col < GRID; col++) {
				this.addSlot(new Slot(craftSlots, col + row * GRID, 8 + col * 18, 18 + row * 18));
			}
		}
		// Result to the right of grid
		this.addSlot(new ResultSlot(resultSlots, 0, 152, 72));

		// Player inventory below
		int invY = 156;
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInv, col + row * 9 + 9, 8 + col * 18, invY + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInv, col, 8 + col * 18, invY + 58));
		}
	}

	private class ResultSlot extends Slot {
		public ResultSlot(Container container, int index, int x, int y) {
			super(container, index, x, y);
		}
		@Override public boolean mayPlace(ItemStack stack) { return false; }
		@Override public boolean mayPickup(Player player) { return hasItem(); }
		@Override
		public void onTake(Player player, ItemStack stack) {
			consumeIngredientsOnce();
			updateResult();
			super.onTake(player, stack);
		}
		@Override
		public ItemStack remove(int amount) {
			ItemStack current = getItem();
			if (current.isEmpty()) return ItemStack.EMPTY;
			ItemStack taken = current.copy();
			set(ItemStack.EMPTY);
			return taken;
		}
	}

	private void consumeIngredientsOnce() {
		craftSlots.silent = true;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) {
				s.shrink(1);
				if (s.isEmpty()) craftSlots.items.set(i, ItemStack.EMPTY);
			}
		}
		craftSlots.silent = false;
	}

	private int maxCraftsPossible() {
		ItemStack result = computeResult();
		if (result.isEmpty()) return 0;
		int max = 64;
		for (int i = 0; i < GRID_SIZE; i++) {
			ItemStack s = craftSlots.getItem(i);
			if (!s.isEmpty()) max = Math.min(max, s.getCount());
		}
		return Math.max(0, max);
	}

	@Override
	public void slotsChanged(Container container) {
		if (level == null || level.isClientSide) return;
		updateResult();
	}

	private void updateResult() {
		resultSlots.setItem(0, computeResult());
		broadcastChanges();
	}

	private ItemStack computeResult() {
		int f = filled();

		// Full 7x7 = 49 of same material → next tier
		if (f == 49 && count(Items.REDSTONE_BLOCK) == 49)
			return new ItemStack(ModItems.COMPACTED_REDSTONE);
		if (f == 49 && count(ModItems.COMPACTED_REDSTONE) == 49)
			return new ItemStack(ModItems.REDSTONE_2X);
		if (f == 49 && count(ModItems.REDSTONE_2X) == 49)
			return new ItemStack(ModItems.REDSTONE_3X);
		if (f == 49 && count(ModItems.REDSTONE_3X) == 49)
			return new ItemStack(ModItems.REDSTONE_COMPLETE);
		if (f == 49 && count(Items.IRON_BLOCK) == 49)
			return new ItemStack(ModItems.COMPACTED_IRON);
		if (f == 49 && count(ModItems.COMPACTED_IRON) == 49)
			return new ItemStack(ModItems.IRON_2X);
		if (f == 49 && count(ModItems.IRON_2X) == 49)
			return new ItemStack(ModItems.IRON_3X);
		if (f == 49 && count(ModItems.IRON_3X) == 49)
			return new ItemStack(ModItems.IRON_COMPLETE);
		if (f == 49 && count(ModItems.PHOTON_FRAGMENT) == 49)
			return new ItemStack(ModItems.PHOTON_SEMI);
		if (f == 49 && count(ModItems.PHOTON_SEMI) == 49)
			return new ItemStack(ModItems.PHOTON_COMPLETE);

		// 48 complete + eye center → 2 vortex flow
		if (f == 49 && count(ModItems.REDSTONE_COMPLETE) == 48
				&& craftSlots.getItem(CENTER).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.REDSTONE_FLOW, 2);
		if (f == 49 && count(ModItems.IRON_COMPLETE) == 48
				&& craftSlots.getItem(CENTER).is(ModItems.SPELEOLOGIST_EYE))
			return new ItemStack(ModItems.IRON_FLOW, 2);

		if (isFirstFlowRecipe())
			return new ItemStack(ModItems.FIRST_FLOW, 1);

		// Black vortex: cross of 4 photon_complete + eye center (can be placed anywhere matching pattern)
		if (isBlackVortexRecipe())
			return new ItemStack(ModItems.BLACK_VORTEX);

		// Scanner: pattern with black vortex center
		if (isScannerRecipe())
			return new ItemStack(ModItems.CYBER_SCANNER);

		return ItemStack.EMPTY;
	}

	/** 4 photon_complete in + shape around eye at center of used area, or simple: 4 complete + 1 eye */
	private boolean isBlackVortexRecipe() {
		if (count(ModItems.SPELEOLOGIST_EYE) != 1) return false;
		if (count(ModItems.PHOTON_COMPLETE) != 4) return false;
		if (filled() != 5) return false;
		return true;
	}

	private boolean isScannerRecipe() {
		// 4 ender eye, 2 compacted iron, 2 compacted redstone, 1 black vortex — any layout count match
		if (count(Items.ENDER_EYE) != 4) return false;
		if (count(ModItems.COMPACTED_IRON) != 2) return false;
		if (count(ModItems.COMPACTED_REDSTONE) != 2) return false;
		if (count(ModItems.BLACK_VORTEX) != 1) return false;
		return filled() == 9;
	}

	private int count(Item item) {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			if (craftSlots.getItem(i).is(item)) n++;
		}
		return n;
	}

	private int filled() {
		int n = 0;
		for (int i = 0; i < GRID_SIZE; i++) {
			if (!craftSlots.getItem(i).isEmpty()) n++;
		}
		return n;
	}

	/** Center = ender eye; 8 diamond blocks; 8 redstone vortex; 8 iron vortex */
	private boolean isFirstFlowRecipe() {
		if (!craftSlots.getItem(CENTER).is(Items.ENDER_EYE)) return false;
		int diamonds = count(Items.DIAMOND_BLOCK);
		int rf = count(ModItems.REDSTONE_FLOW);
		int irf = count(ModItems.IRON_FLOW);
		return diamonds == 8 && rf == 8 && irf == 8 && filled() == 25;
	}

	@Override
	public ItemStack quickMoveStack(Player player, int index) {
		Slot slot = this.slots.get(index);
		if (slot == null || !slot.hasItem()) return ItemStack.EMPTY;

		if (index == GRID_SIZE) {
			ItemStack assembled = ItemStack.EMPTY;
			int crafts = 0;
			int maxCrafts = Math.min(maxCraftsPossible(), 64);
			while (crafts < maxCrafts) {
				ItemStack result = computeResult();
				if (result.isEmpty()) break;
				ItemStack single = result.copy();
				if (!this.moveItemStackTo(single, GRID_SIZE + 1, this.slots.size(), true)) break;
				consumeIngredientsOnce();
				crafts++;
				assembled = result.copy();
			}
			updateResult();
			return assembled;
		}

		ItemStack original = slot.getItem();
		ItemStack copy = original.copy();
		if (index > GRID_SIZE) {
			if (!this.moveItemStackTo(original, 0, GRID_SIZE, false)) return ItemStack.EMPTY;
		} else {
			if (!this.moveItemStackTo(original, GRID_SIZE + 1, this.slots.size(), false)) return ItemStack.EMPTY;
		}
		if (original.isEmpty()) slot.setByPlayer(ItemStack.EMPTY);
		else slot.setChanged();
		updateResult();
		return copy;
	}

	@Override
	public boolean stillValid(Player player) {
		return stillValid(this.access, player, com.speleologist.block.ModBlocks.ADVANCED_CRAFTING_TABLE);
	}

	@Override
	public void removed(Player player) {
		super.removed(player);
		this.access.execute((level, pos) -> this.clearContainer(player, this.craftSlots));
	}

	static class CraftingContainer implements Container {
		final NonNullList<ItemStack> items;
		final AdvancedCraftingMenu menu;
		boolean silent;

		CraftingContainer(AdvancedCraftingMenu menu, int size) {
			this.menu = menu;
			this.items = NonNullList.withSize(size, ItemStack.EMPTY);
		}
		@Override public int getContainerSize() { return items.size(); }
		@Override public boolean isEmpty() { return items.stream().allMatch(ItemStack::isEmpty); }
		@Override public ItemStack getItem(int i) { return items.get(i); }
		@Override public ItemStack removeItem(int i, int c) {
			ItemStack r = ContainerHelper.removeItem(items, i, c);
			if (!r.isEmpty() && !silent) menu.slotsChanged(this);
			return r;
		}
		@Override public ItemStack removeItemNoUpdate(int i) { return ContainerHelper.takeItem(items, i); }
		@Override public void setItem(int i, ItemStack stack) {
			items.set(i, stack);
			if (!silent) menu.slotsChanged(this);
		}
		@Override public void setChanged() {}
		@Override public boolean stillValid(Player player) { return true; }
		@Override public void clearContent() { items.clear(); }
	}
}
