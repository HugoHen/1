# Antenden — /give commands

Replace PLAYER with your name.

## Core
```
/give PLAYER olho_do_espeleologo:speleologist_eye
/give PLAYER olho_do_espeleologo:cyber_scanner
/give PLAYER olho_do_espeleologo:a_ultima
```

## Armor
```
/give PLAYER olho_do_espeleologo:cyber_helmet
/give PLAYER olho_do_espeleologo:cyber_chestplate
/give PLAYER olho_do_espeleologo:cyber_leggings
/give PLAYER olho_do_espeleologo:cyber_boots
```

## Photons & vortex
```
/give PLAYER olho_do_espeleologo:photon_fragment
/give PLAYER olho_do_espeleologo:photon_semi
/give PLAYER olho_do_espeleologo:photon_complete
/give PLAYER olho_do_espeleologo:redstone_flow
/give PLAYER olho_do_espeleologo:iron_flow
/give PLAYER olho_do_espeleologo:first_flow
/give PLAYER olho_do_espeleologo:black_vortex
/give PLAYER olho_do_espeleologo:vortex_foundry
```

## New
```
/give PLAYER olho_do_espeleologo:star
/give PLAYER olho_do_espeleologo:big_star
/give PLAYER olho_do_espeleologo:black_hole
```

## Blocks
```
/give PLAYER olho_do_espeleologo:advanced_crafting_table
/give PLAYER olho_do_espeleologo:photon_ore
/give PLAYER olho_do_espeleologo:compacted_redstone
/give PLAYER olho_do_espeleologo:redstone_2x
/give PLAYER olho_do_espeleologo:redstone_3x
/give PLAYER olho_do_espeleologo:redstone_complete
/give PLAYER olho_do_espeleologo:compacted_iron
/give PLAYER olho_do_espeleologo:iron_2x
/give PLAYER olho_do_espeleologo:iron_3x
/give PLAYER olho_do_espeleologo:iron_complete
```

Note: the mod id is `olho_do_espeleologo` (not antedeguemon). All items work with /give.
