package com.speleologist.client.renderer;

import com.speleologist.block.ExtractorBlockEntity;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

public class ExtractorRenderer extends GeoBlockRenderer<ExtractorBlockEntity> {
	public ExtractorRenderer(BlockEntityRendererProvider.Context context) {
		super(new GeoModel<>() {
			@Override
			public ResourceLocation getModelResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "geo/block/extractor.geo.json");
			}
			@Override
			public ResourceLocation getTextureResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "textures/block/extractor.png");
			}
			@Override
			public ResourceLocation getAnimationResource(ExtractorBlockEntity a) {
				return ResourceLocation.fromNamespaceAndPath("antenden", "animations/block/extractor.animation.json");
			}
		});
	}
}
